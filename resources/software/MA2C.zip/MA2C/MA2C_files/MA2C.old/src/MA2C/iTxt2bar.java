/*
 * iTxt2bar.java
 *
 * Created on 2006��11��16��, ����3:07
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

/**
 *
 * @author zhuxp
 */
public class iTxt2bar {
    
    /** Creates a new instance of iTxt2bar */
    public iTxt2bar() {
    }
    
}
