/*
 * MapRatios.java
 *
 * Created on 2006��10��9��, ����2:16
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

/**
 *
 * @author zhuxp
 */
public class MapRatios {
    public ProbeMap map = null;
    public Double[][] RatioLists = null;
    String[] filenames;
    String DesignID;
    int ReplicatesNum;
    /** Creates a new instance of MapRatios */
    public MapRatios() {
    }
    public MapRatios(String probemap_fn,String[] ratios_fn)
    {
        
        this.map=new ProbeMap(probemap_fn);
        
        _generate_ratio_list(ratios_fn);
        
    }
    public MapRatios(String probemap_fn,String ratio_fn)
    {
        String[] a= new String[1];
        a[0]=ratio_fn;
     
       //System.err.println("Rep="+ReplicatesNum);
        this.map=new ProbeMap(probemap_fn);
        _generate_ratio_list(a);
        
      
    }
    public MapRatios(ProbeMap probemap, Ratio[] ratios)
    {
        this.map=probemap;
        this.filenames = new String[ratios.length];
        this.RatioLists = new Double[ratios.length][];
        this.ReplicatesNum = ratios.length;
        for(int i=0;i<ratios.length;i++)
        {
         this.RatioLists[i]=Ratio2List(ratios[i]);   
        }
    }
    
    private void _generate_ratio_list(String[] ratios_fn)
    {
        this.ReplicatesNum = ratios_fn.length;
        this.filenames = new String[ratios_fn.length];
        this.RatioLists = new Double[ratios_fn.length][];
        for(int i=0;i<ratios_fn.length;i++)
        {
        Ratio ratio=new Ratio(ratios_fn[i]);
        this.RatioLists[i]=Ratio2List(ratio);
        this.filenames[i]=ratios_fn[i];
        this.DesignID=ratio.DESIGN_ID;
        }
    }
    public MapRatios(String map,String[] ratios_fn,boolean binary)
    {
        if(binary)
        {
        this.ReplicatesNum = ratios_fn.length;
        this.map=(ProbeMap)GzipIO.readFromGzip(map);
        this.filenames = new String[ratios_fn.length];
        this.RatioLists = new Double[ratios_fn.length][];
        for(int i=0;i<ratios_fn.length;i++)
        {
        Ratio ratio=(Ratio)GzipIO.readFromGzip(ratios_fn[i]);
        //System.err.println("ratio "+i+"\n");
        this.RatioLists[i]=Ratio2List(ratio);
        this.filenames[i]=ratios_fn[i];
        this.DesignID=ratio.DESIGN_ID;
        }
        }
        else
        {
        this.map=new ProbeMap(map);
        _generate_ratio_list(ratios_fn);
         
        }
    }
    
    public Double[] Ratio2List(Ratio ratio)
    {
        int i;
        Double[] RatioList =  new Double[map.probeNum+1];
       
        for (i=0;i<map.probeNum;i++)
        {
            RatioList[i]=ratio.RatioTable[map.X[i]][map.Y[i]];
        }
        return RatioList;
    }
    public Double[] getProbeRatios(int j)
    {
        Double[] a = new Double[ReplicatesNum];
        
        for(int i=0;i<ReplicatesNum;i++)
        {
            //System.out.println("j="+j+"\ti="+i);
            
            a[i]=this.RatioLists[i][j];
        }
        return a;
    }
    public int getReplicatesNum()
    {
        return ReplicatesNum;
    }
    
    public int length()
    {
        return map.probeNum;
    }
    private String Probe2String(int i)
    {
        String a = "";
        long stop = map.Start[i]+map.Len[i]-1;
        a=i+"\t"+map.ChrID[map.Chr[i]].toString()+"\t"+map.Start[i]+"\t"+stop;
        for(int j=0;j<this.ReplicatesNum;j++)
        {
            a+="\t"+this.RatioLists[j][i].toString();
        }
      
        return a;
    }
    private String Probes2String(int start,int stop)
    {
        String a="";
        for(int j=start;j<=stop;j++)
        {
            a=a+Probe2String(j)+"\n";
        }
        return a;
    }
    public String Locus2ProbesString(String chr,long start,long stop)
    {
        int[] a=this.map.Locus2ListPos(chr,start,stop);
        String b="Region: "+chr+" "+start+" "+stop+"  Probe "+a[0]+" to "+a[1]+"\n";
        b=b+Probes2String(a[0],a[1]);
        return b;
    }
  
     public static void main (String[] argv){
        String[] ratio_fn = new String[3];
        ratio_fn[0] = "/Users/zhuxp/Desktop/nimb_spike/PairData/C2_normalized/MA2C_49875_normalized.txt.bin.gz";
        ratio_fn[1] = "/Users/zhuxp/Desktop/nimb_spike/PairData/C2_normalized/MA2C_49880_normalized.txt.bin.gz";
        ratio_fn[2] = "/Users/zhuxp/Desktop/nimb_spike/PairData/C2_normalized/MA2C_49883_normalized.txt.bin.gz";
        
        String map_fn="/Users/zhuxp/Desktop/nimb_spike/DesignFiles/MA2C_1944.tpmap.bin.gz";
        MapRatios a= new MapRatios(map_fn,ratio_fn,true);
       
        System.out.println(a.Locus2ProbesString("chr1",148330000,148340000));
        
        }
     
    
}
