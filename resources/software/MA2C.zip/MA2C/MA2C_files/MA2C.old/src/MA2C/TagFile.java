/*
 * TagFile.java
 *
 * Created on 2006
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

/**
 *
 * @author zhuxp
 */
public class TagFile {
    public HashMap tags = null;
    
    /** Creates a new instance of TagFile */
    public TagFile() {
        tags = new HashMap();
    }
    public TagFile(String filename)
    {
        tags = new HashMap();
        parsefile(filename);
    }
    
    void parsefile(String filename) 
    {
        BufferedReader f;
        try {
            f = new BufferedReader(new FileReader(filename));
      
       String line;
           String last=""; 
       
        while((line =f.readLine())!= null)
        {
           if (line.trim().indexOf("#") == 0)
            {    
            }
            else if(line.indexOf("=")>0)
            {
            String[] t=line.split("=");
            last = t[0].trim();
           // System.err.println("in = "+last);
            tags.put(t[0].trim(),t[1].trim());
            }
            else if(line.trim().length()==0)
            {
            // System.err.println("skipping");  
            }
            else
            {
               /*
               System.err.println(last);
               System.err.println(tags.get(last));
               System.err.println(line.trim());
               */
               tags.put(last,tags.get(last)+" "+line.trim());
            }
        }
       
        } catch (Exception ex) {
            ex.printStackTrace();
        }
       
        
       
       
       
    }
    public String getTag(String key)
    {
        if(tags.containsKey(key))
        {
        return (String)tags.get(key);
        }
        else
        {
            return null;
        }
   }
    
     public static void main(String[] args) {
      TagFile a= new TagFile("/Users/zhuxp/Desktop/nimb_spike/replicates.tag");
      System.out.println("DesignFilesDir = "+a.getTag("DesignFilesDir"));
      System.out.println("RatioData      = "+a.getTag("RatioData"));
      
     }
    
}
