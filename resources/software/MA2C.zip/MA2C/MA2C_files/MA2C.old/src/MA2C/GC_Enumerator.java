/*
 * GC_Enumerator.java
 *
 * Created on July 24, 2006, 2:22 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;
import java.io.BufferedReader;     
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.Vector;
import java.io.FileReader;
import java.util.Hashtable;
/**
 *
 * @author jssong
 */
public class GC_Enumerator {
    String filename="";
    Hashtable seqTable= new Hashtable();
    int[][] GCTable = null;
    String DESIGN_ID = null;
    /** Creates a new instance of GC_Enumerator */
    public GC_Enumerator(String filename) {
        this.filename = filename;
        readGC();
    }
    
    /** Check design ID **/
    public GC_Enumerator(String filename, String DESIGN_ID) {
        this.filename = filename;
        this.DESIGN_ID = DESIGN_ID;
        readGC();
        
    }
    /** Read the .ndf file and compute the GC content of probes
     *  The result will be stored as a hashtable in seqTable **/
    void readGC(){
        Vector<String[]> lines = new Vector<String[]>();
        String line = null;
        int probeColIndex=0;  // column index for probe IDs
        int seqColIndex=0;    // column index for sequence
        int designIDIndex = 0;
        int xMax=0, yMax = 0;
        try{
            BufferedReader f = new BufferedReader (new FileReader(filename));
            while ( (line =f.readLine())!= null) {
                    if (line.trim().indexOf("#") == 0) {
                        if (line.indexOf("XYdimension") >=0){
                            String[] l = line.split("\t");
                            xMax = Integer.parseInt(l[1]);
                            yMax = Integer.parseInt(l[2]);
                            GCTable = new int[xMax+1][yMax+1];
                        }
                            
                    }
                    else{
                        break;
                    }
            }
            String [] columns = null;
          
         
            do{
                int GCcount = 0;
                columns = line.split("\t");
                int X = Integer.parseInt(columns[4]);
                int Y = Integer.parseInt(columns[5]);
                
                char[] tmpseq = columns[seqColIndex].trim().toUpperCase().toCharArray();
                for (int j = 0; j < tmpseq.length; j++){
                    if (tmpseq[j] == 'C' || tmpseq[j] == 'G') GCcount ++;
                }
                GCTable[X][Y] = GCcount;
            }  while((line=f.readLine())!= null);
           
            //System.out.println(GCTable[507][987]);
            //System.out.println(seqTable.get("CHR5P64098620")); 
            f.close();
        } catch (IOException io){
            System.err.print("Cannot open " + filename );
        }
        
    }
    
    public static void main(String[] argv){
        GC_Enumerator GC = new GC_Enumerator("C:\\cygwin\\home\\jssong\\Research\\FisherLab\\DesignFiles\\MA2C_1702.tpmap");
        
    }
}
