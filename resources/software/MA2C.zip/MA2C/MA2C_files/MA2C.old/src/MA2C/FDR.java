/*
 * FDR.java
 *
 * Created on 2006��10��19��, ����1:45
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

/**
 *
 * @author zhuxp
 */
public class FDR {
    double cut;
    double FDR;
    double pvaluecut;
    int pos;
    int neg;
    /** Creates a new instance of FDR */
    public FDR() {
    }
    public FDR(double FDR,double cut,double pvaluecut,int pos,int neg)
    {
        this.FDR=FDR;
        this.cut=cut;
        this.pvaluecut=pvaluecut;
        this.pos=pos;
        this.neg=neg;
    }
    public String toString()
    {
        String a="";
        a=a+FDR+"\t"+cut+"\t"+pvaluecut+"\t"+pos+"\t"+neg;
        return a;
        
    
    }
}
