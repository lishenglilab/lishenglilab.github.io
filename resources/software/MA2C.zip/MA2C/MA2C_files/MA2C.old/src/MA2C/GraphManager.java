/*
 * GraphManager.java
 *
 * Created on August 2, 2006, 12:48 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

import java.io.IOException;
import java.util.Random;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.data.statistics.HistogramDataset;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 *
 * @author jssong
 */
public class GraphManager {
    
    /** Creates a new instance of GraphManager */
    public GraphManager() {
    }
    
    public static void showHistograms(double[][] list, int nBin, String[] header){
        showHistograms(list, nBin, header, "", null);
    }
    public static void showHistograms(double[][] list, int nBin, String[] header, String info){
        showHistograms(list, nBin, header, info, null);
    }
    public static void showHistograms(double[][] list, int nBin, String[] header, String info, String outpath){
        int nGraphs = list.length;

        // Can only display 3 graphs at once
       
        JPanel[] chartPanel = new JPanel[nGraphs];
        for (int k = 0 ; k < nGraphs; k ++){
            HistogramDataset dataset = new HistogramDataset();
            double[] minMax = getMinMax(list[k]);
            
            dataset.addSeries ("Probe Histogram", list[k], nBin, minMax[0], minMax[1]);
            
            JFreeChart chart = ChartFactory.createHistogram(
                header[k], 
                "log-ratio intensity", 
                null, 
                dataset, 
                PlotOrientation.VERTICAL, 
                true, 
                false, 
                false
                );
//            XYPlot plot = (XYPlot) chart.getPlot();
//            plot.setForegroundAlpha(0.85f);
//            XYBarRenderer renderer = (XYBarRenderer) plot.getRenderer();
//            renderer.setDrawBarOutline(false);
            XYPlot p = (XYPlot) chart.getPlot();
            ValueAxis axis = p.getRangeAxis();
            double bound = axis.getUpperBound();
            if (minMax[1] > 1.5) axis.setRange(0.0d,50.0d);  
            chartPanel[k] =  new ChartPanel(chart);
            header[k] = info +" " + header[k];
        }
        
        if(outpath == null){
            new GraphFrame(chartPanel, header);
        } else{
            GraphFrame gf = new GraphFrame(chartPanel, header, outpath);
            gf.setTitle(outpath);
            gf.automaticSave();
        }
    }
    public static void showHistogramsAndFDR(double[][] list, int nBin, String[] header, double[][] FDRdata, String info, String outpath){
        int nGraphs = list.length;
        int nFDR = FDRdata.length;
        // Can only display 3 graphs at once
       
        JPanel[] chartPanel = new JPanel[nGraphs+1];
        for (int k = 0 ; k < nGraphs; k ++){
            HistogramDataset dataset = new HistogramDataset();
            double[] minMax = getMinMax(list[k]);
            
            dataset.addSeries ("Probe Histogram", list[k], nBin, minMax[0], minMax[1]);
            
            String xAxisLabel = "log-ratio intensity";
            if (header[k].equals("Pvalue")) xAxisLabel = "P-value";
            JFreeChart chart = ChartFactory.createHistogram(
                header[k], 
                xAxisLabel, 
                null, 
                dataset, 
                PlotOrientation.VERTICAL, 
                true, 
                false, 
                false
                );
//            XYPlot plot = (XYPlot) chart.getPlot();
//            plot.setForegroundAlpha(0.85f);
//            XYBarRenderer renderer = (XYBarRenderer) plot.getRenderer();
//            renderer.setDrawBarOutline(false);
            XYPlot p = (XYPlot) chart.getPlot();
            ValueAxis axis = p.getRangeAxis();
            double bound = axis.getUpperBound();
            if (minMax[1] > 1.5) axis.setRange(0.0d,50.0d);  
            chartPanel[k] =  new ChartPanel(chart);
            header[k] = info +" " + header[k];
        }
        
        // add FDR panel
        XYSeries series1 = new XYSeries("FDR");
        for (int i = 0; i < nFDR; i ++){
            if (FDRdata[i][0] > 50.0) continue;
            series1.add(FDRdata[i][0], FDRdata[i][1]);
        }
        header[nGraphs] = info +" " + header[nGraphs];
        XYDataset dataset = new XYSeriesCollection(series1);
        JFreeChart chart = ChartFactory.createScatterPlot("FDR Table","FDR(%)","#Positive Peaks - #Negative Peaks",dataset,PlotOrientation.VERTICAL,false,true,false);
        chartPanel[nGraphs] = new ChartPanel(chart);
        
        if(outpath == null){
            new GraphFrame(chartPanel, header);
        } else{
            GraphFrame gf = new GraphFrame(chartPanel, header, outpath);
            gf.setTitle(outpath);
            gf.automaticSave();
        }
    }
    public static void showScatter(){
        XYSeries series1 = new XYSeries("Series 1");
        series1.add(10.0, 10.0);
        series1.add(20.0, 20.0);
        series1.add(30.0, 30.0);
        XYDataset dataset = new XYSeriesCollection(series1);
        JFreeChart chart = ChartFactory.createScatterPlot("test","x","y",dataset,PlotOrientation.VERTICAL,true,true,false);
        JPanel[] chartPanel =  new JPanel[1];
        chartPanel[0] = new ChartPanel(chart);
        new GraphFrame(chartPanel, "Test Scatter Plot");
    }
    
    private static double[] getMinMax(double[] array){
        double min = Double.MAX_VALUE;
        double max = Double.MIN_VALUE;
        int nElements = array.length;
        double tmp;
        for (int k =0 ; k < nElements; k ++){
            tmp = array[k];
            if ( tmp < min ) min = tmp;
            if (tmp > max) max = tmp;
        }
        
        return new double[] {min, max};
    }
    
    public static void main (String[] argv){
//        String norm = "C:\\cygwin\\home\\jssong\\Research\\FisherLab\\PairData\\MA2C_43412_normalized.txt";
//        double[][] array =  new double[1][];
//        array[0]=PairDataReader.readNormalizedData(norm);
//        GraphManager.showHistograms(array, 10000, new String[]{"test"}, "foo foo");
        GraphManager.showScatter();
        
    }
}
