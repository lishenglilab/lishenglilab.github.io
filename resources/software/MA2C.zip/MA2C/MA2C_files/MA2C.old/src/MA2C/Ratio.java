/*
 * NormalizedDataMap.java
 *
 * Created on 2006��8��3��, ����12:00
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 *
 * @author zhuxp
 * Ratio Class Read the normailized file from MA2C
 * It stored the normalized ratio value from expriment  in a two dimension array.
 * 
 */
public class Ratio implements Serializable {
    String filename=""; //ratio file name
    int xMax=0;  // the default max x coodination of this array
    int yMax=0; // the default max y coodination of thie array
    String DESIGN_ID = "";
    double[][] RatioTable = null; // the ratio value table 
   
    /** Creates a new instance of NormalizedDataMap */
    public Ratio()
    {
        
    }
    public Ratio(String filename) {
        this.filename=filename;
        
       
        readLogRatio();
        
    }
   
   
    public void writeLogRatio(String filename)
    {
        
    }

    public void readLogRatio()
    {
         String line = null;
         ArrayList<Integer> XList = new ArrayList<Integer>();
         ArrayList<Integer> YList = new ArrayList<Integer>();
         ArrayList<Double> ratioList = new ArrayList<Double>();
         xMax=0;
         yMax=0;
        
        try{
            BufferedReader f = new BufferedReader (new FileReader(filename));
            
            while ( (line =f.readLine())!= null) {
                    if (line.trim().indexOf("#") == 0) {
                        if (line.indexOf("DESIGN_ID") >=0){
                            String[] l = line.split("\t");
                            DESIGN_ID = l[1];
                        }
                      
                            
                    }
                    else{
                        break;
                    }
            }
            //System.out.println(DESIGN_ID+" "+line);
           
            String [] columns = null;
            //now in line is the X Y definition line;
         
            while((line=f.readLine())!= null)
           {
              //  System.out.println(line);          
            
                columns = line.split("\t");
                int X = Integer.parseInt(columns[0]);
                int Y = Integer.parseInt(columns[1]);
                double ratio= Double.parseDouble(columns[2]);
                XList.add(X);
                YList.add(Y);
                ratioList.add(ratio);
               if(xMax<X){xMax=X;}
               if(yMax<Y){yMax=Y;} 
                
            }  
           
          
            f.close();
        } catch (IOException io){
            System.err.print("Cannot open " + filename );
        }
         XList.trimToSize();
         YList.trimToSize();
         ratioList.trimToSize();
        try
        {
        RatioTable = new double[xMax+1][yMax+1];
        //System.err.println(xMax+","+yMax);
        }
        catch(Exception E) 
        {
            System.err.println("out of memory in allocating RatioTable");
        }
          for(int i=0;i<ratioList.size();i++)
          {
             int X = XList.get(i);
             int Y = YList.get(i);
             double r = ratioList.get(i);
             RatioTable[X][Y] = r;
          }
    }
    private void writeObject(ObjectOutputStream out) throws IOException
    {
      out.writeObject(DESIGN_ID);
      out.writeInt(xMax);
      out.writeInt(yMax);
      out.writeObject(RatioTable);
      out.writeObject(filename);
        
    }
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
    {
        DESIGN_ID=(String)in.readObject();
        xMax=in.readInt();
        yMax=in.readInt();
        RatioTable=(double[][]) in.readObject();
        filename=(String) in.readObject();
        
    }
    
    
    
    public static void main(String[] args)
    {
      System.err.println("Reading");  
      Ratio a=new Ratio(args[0]);
      System.err.println("Writing");
      GzipIO.writeToGzip(args[0]+".bin.gz",a);
      System.err.println("Ending");
      //System.out.println(a.xMax);
      //Ratio b = (Ratio)GzipIO.readFromGzip("/Users/zhuxp/Desktop/nimb_spike/test.ratio.bin.gz");
      //System.out.println(b.DESIGN_ID+"\t"+b.RatioTable[5][4]);
        
    }
    
}





    
