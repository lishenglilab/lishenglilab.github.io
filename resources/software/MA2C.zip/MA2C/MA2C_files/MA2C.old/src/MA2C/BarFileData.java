package MA2C;

import java.io.BufferedOutputStream;
import java.io.DataOutput;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
/*
 * Annotation.java
 *
 * Created on 2006��10��27��, ����12:16
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author zhuxp
 */
public class BarFileData {
    public static int BYTE8_FLOAT = 0;
    public static int BYTE4_FLOAT = 1;
    public static int BYTE4_SIGNED_INT = 2;
    public static int BYTE2_SIGNED_INT = 3;
    public static int BYTE1_SIGNED_INT = 4;
    public static int BYTE4_UNSIGNED_INT = 5;
    public static int BYTE2_UNSIGNED_INT = 6;
    public static int BYTE1_UNSIGNED_INT = 7;
    String m_FileName = "";
    float m_Version;
    int m_NumberSequences = 0;
    int m_NumberColumns = 2;
    int m_NumberParameters = 0;
    HashMap m_Parameter=new HashMap();
    ArrayList<BarSequenceItem> m_SequenceItems = new ArrayList();
    /** Creates a new instance of Annotation */
    public BarFileData() {
    }
    public  void SetFileName(String name) {
        this.m_FileName=name;
    }
    public String GetFileName() {
        return this.m_FileName;
    }
//boolean 	Read ()
//boolean 	ReadHeader ()
//boolean 	Exists ()
//void 	Close ()
//std::string 	GetError () const
    public float 	GetVersion() {
        return this.m_Version;
    }
    public int 	GetNumberSequences() {
        return this.m_NumberSequences;
    }
    public int 	GetNumberColumns() {
        return this.m_NumberColumns;
    }
    public int 	GetNumberParameters() {
        return this.m_NumberParameters;
    }
    public String GetParameter(String tag) {
        return (String)m_Parameter.get(tag);
    }
// 	GetColumnTypes (int index)
//GetResults (int index)
    public void 	AddAlgorithmParameter(String tag, String value) {
        m_Parameter.put(tag,value);
    }
/*
void 	AddColumn (GDACFILES_BAR_DATA_TYPE ctype)
{
 
}
 */
    public void SetNumberSequences(int n) {
        m_NumberSequences=n;
    }
    public BarSequenceItem GetResultsPtr(int index) {
        return m_SequenceItems.get(index);
    }
    public void AddSequenceItem(BarSequenceItem s) {
        m_SequenceItems.add(s);
        m_NumberSequences++;
    }
    
    public void Save() throws IOException {
        FileOutputStream fos= new FileOutputStream(this.m_FileName);
        BufferedOutputStream bos= new BufferedOutputStream(fos);
        DataOutputStream dos= new DataOutputStream(bos);
        dos.writeBytes("barr\r\n\032\n");//  "barr\r\n\032\n"
       // System.err.println("hello");
        dos.writeFloat(2.0f);       // version of bar format = 2.0
        dos.writeInt(this.m_NumberSequences);  // number of seq data sections in file -- if single graph, then 1
        dos.writeInt(this.m_NumberColumns);  // number of columns (dimensions) per data point
        dos.writeInt(BYTE4_SIGNED_INT);  // int  first column/dimension type ==> 4-byte signed int
        dos.writeInt(BYTE4_FLOAT);  // int  second column/dimension type ==> 4-byte float
        // should write out all properties from group and/or graphs as tag/vals?  For now just saying no tag/vals
        dos.writeInt(m_NumberParameters);
        Object[] keys=m_Parameter.keySet().toArray();
        
        for(int i=0;i<m_NumberParameters;i++) {
            writeTagVal(dos,(String)keys[i],(String)m_Parameter.get(keys[i]));
        }
        for(int i=0;i<m_NumberSequences;i++) {
            m_SequenceItems.get(i).Write(dos);
        }
        dos.close();
            
    }
    public static void writeTagVal(DataOutput dos, String tag, String val)
    throws IOException  {
        dos.writeInt(tag.length());
        dos.writeBytes(tag);
        dos.writeInt(val.length());
        dos.writeBytes(val);
    }
    public static void writeString(DataOutput dos, String str) throws IOException {
        int l=str.length();
        dos.writeInt(l);
        dos.writeBytes(str);
    }
    public static void main(String[] args) {
        BarFileData a=new BarFileData();
        a.SetFileName("/Users/zhuxp/test.bar");
        a.AddAlgorithmParameter("hello","world");
        a.AddAlgorithmParameter("you","me");
        String chr="chr1";
        String version="test";
        String group="hg";
        int[] p=new int[]{2,3};
        float[] v=new float[]{3.0f,4.0f};
        BarSequenceItem b=new BarSequenceItem(chr,version,group,p,v);
        a.AddSequenceItem(b);
        a.AddSequenceItem(b);
        try {
            a.Save();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
}
