/*
 * RunPeak.java
 *
 * Created on 2006��8��3??, ����2:22
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

//import com.sun.org.apache.bcel.internal.verifier.statics.DOUBLE_Upper;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import javax.print.attribute.standard.Chromaticity;
import java.text.DecimalFormat;

/**
 *
 * @author zhuxp
 */
public class RunPeak extends MapRatios{
    
    /** Creates a new instance of RunPeak */
    
    
    
    /*
     * The length of array below is the number of probes.
     */
    
    //float[] RatioList = null;   //Ratio value according to probe list
    double[] MeanList = null;    // Mean value of all probes in nearby
    //double[] MedianList= null;   // Median value of all probes nearby
    double[] PvalueList=null;   //Pvalue of a probe median value
    double[] QvalueList=null;   //Qvalue of a probe median value
    double[] MA2Cscore = null;  //tValue list
    Double[] PeakScore = null; //one of [Pvalue Qvalue or MA2Cscore]
    double[] RatioMedianList=null;
    int[]    NearNList=null; //number of probes nearby;
    int NExcluded = 0;       // number of excluded probes
    /*************** End of Probes Number *************************/
    
    /* Positive and Negative Peaks in BedArray */
    Bed[] BedArray = null;
    
    
    String ScoreMethod=null;
    double CutOff=0.0;
   
    
    /*
     * The Null Model Parameters
     *     Mirroring..
     */
    Double[] SortNullList = null; 
    double NullMean;
    double NullStderr;
    String Name = "";
    //String ScoreMethodThreshold="";
    
    int band_length=250;//default
    int maxGap = 250;   // max gap for adjoining nearby probes > cutoff MA2C score
    int minProbe = 5;   // min # probes in a running window; assign MA2C score 0 if < this number of probes in the window
    FDR[] fdr_table= null;
    public void set_band_length(int bw, int MG, int mP)
    {
        band_length=bw;
        maxGap = MG;
        minProbe = mP;
    }
    public RunPeak(String map,String[] ratios) {
      super(map,ratios);
     
    }

    public RunPeak(String map , String ratio)
    {
        super(map,ratio);
        
       
    }
    public RunPeak(ProbeMap map, Ratio ratio)
    {
        
    }
    public RunPeak(String map,String[] ratios,boolean binary)
    {
        super(map,ratios,binary);
    }
    public RunPeak(String map, String[] ratios,String name)
    {
        
        this(map,ratios);
        this.Name=name;
    }
    
    public RunPeak(ProbeMap map,Ratio[] ratios)
    {
        super(map,ratios);
        
    }
    
   public RunPeak()
   {
       
   }
   public void SetName(String name)
   {
       this.Name=name;
   }
    
   
  
    /*old version
    private double MedianInBand(int probe_no)
    {
        int[] index=ProbesNearByBand(probe_no);
        double sum=0;
        int number=index[1]-index[0]+1;
        NearNList[probe_no]=number;
        double mean=0;
        ArrayList<Double> a = new ArrayList<Double>();
        //System.err.println("ReplicatesNum="+this.ReplicatesNum);
       for(int j=0;j<this.ReplicatesNum;j++)
       
       {
            
        for(int i=index[0];i<=index[1];i++)
        {
            a.add(RatioLists[j][i]);
            
        }
       }
        Double[] b = a.toArray(new Double[a.size()]);
        Double median=MyStat.median(b); 
        return median;
    }
     */
    /** end of old version **/
    /** it works but may need change to newer version*/
  
    
    private double[][] ProbeInBandMatrix(int probe_no)
    {
        int[] index=ProbesNearByBand(probe_no);
        int probeNumInBand=index[1]-index[0]+1;
        NearNList[probe_no]=probeNumInBand;           //  Count number of probes in the running window, jssong 1/24/07
        if (probeNumInBand < minProbe) NExcluded ++;  // jssong, 1/24/07
        double[][] mat = new double[this.ReplicatesNum][probeNumInBand];
        
        for(int i=0;i<this.ReplicatesNum;i++)
       
       {
            
        for(int j=index[0];j<=index[1];j++)
        {
            mat[i][j-index[0]]=RatioLists[i][j];
            
        }
       }
        return mat;
        
    }
    
    
  private void RunMedianList()
    {
       
        for(int i=0;i<map.probeNum;i++)
        {
          
           double[][] mat=ProbeInBandMatrix(i);
           MA2Cscore[i]=MA2CScore.MedianInBand(mat);
           
        }
     
    }
     
    private void RunMedianPolish()
    {
        for(int i=0; i<map.probeNum;i++)
        {
            double[][] mat=ProbeInBandMatrix(i);
          //  if (i%1000==0) {System.out.println(i);}//debug
            MA2Cscore[i] = MA2CScore.MeanOfMedianPolish(mat);
        }
        
    }
    private void RunPseudoMedian()
    {
        for(int i=0; i<map.probeNum;i++)
        {
            double[][] mat=ProbeInBandMatrix(i);
    //        if (i%1000==0) {System.out.println(i);}//debug
            MA2Cscore[i] = MA2CScore.PseudoMedianInBand(mat);
        }
        
    }
    private void RunTrimMean()
    {
        for(int i=0; i<map.probeNum;i++)
        {
            double[][] mat=ProbeInBandMatrix(i);
            //if (i%1000==0) {System.out.println(i);}//debug
            MA2Cscore[i] = MA2CScore.TrimMeanInBand(mat);
        }
        
    }
    
    /*
     *  Left and right boundary probes (inclusive) within the window
     */
    private int[] ProbesNearByBand(int probe_no)
    {
     
        int lindex=1;
        while(isNearby(probe_no,probe_no-lindex))
        {

          lindex++;
        }
        int rindex=1;
        while(isNearby(probe_no,probe_no+rindex))
        {

          rindex++;
        }

         int s1=probe_no-lindex+1;
         int s2=probe_no+rindex-1;
         int[] a = {s1,s2};
         return a;    
    }
    
    /*
     * Returns True if the distance between no1 and no2 probes is <= band_length 
     */
    private boolean isNearby(int no1,int no2)
    {
        if (no2 < 0 || no1 < 0) 
          {
            return false;
          }
        if (no2 >= map.Start.length || no1 >= map.Start.length)
        {
            return false;
        }
        if (map.Chr[no1]!=map.Chr[no2]) {return false;}
        else if (Math.abs(map.Start[no1]+map.Len[no1]/2-(map.Start[no2]+map.Len[no2]/2))>band_length) {
            return false;
        }
        else 
        {
            return true;
        }
                
    }
    
   
    
    
    private void RunNullList()
    {
        //System.err.println("RunNullList Now");
        ArrayList<Double>  Nulls= new ArrayList();
        int null_index=0;
        Nulls.add(MA2Cscore[0]);
        for(int i=1;i<map.probeNum;i++)
        {
            if (NearNList[i] < minProbe) continue;        // Ignore probes with < minProbe in the running window, jssong
            
            if(Math.abs(map.Start[i]-map.Start[null_index])>2*band_length)
            {
                Nulls.add(MA2Cscore[i]);null_index=i;
            }
            
        }
        SortNullList=(Double[]) Nulls.toArray(new Double[Nulls.size()]);
        //changing NullList into mirror;
      
        
        Arrays.sort(SortNullList);
        NullModel();
       
     }
   
    
       
    private void NullModel()
    {
        //System.err.println("Null Modeling");
        int nullLength=SortNullList.length;
        double median=SortNullList[nullLength/2];
        
        for(int i=0;i<=nullLength/2;i++)
        {
           
            SortNullList[nullLength-i-1]=2*median-SortNullList[i];
        }
      
        //NullMean=MyStat.mean(SortNullList);
        NullMean=median;
        NullStderr=MyStat.stderr(SortNullList);
       
    }
    private double pValue(double median)//could change to Normalization.
    {
      
         
        double x=(double)median;
        double u=(double)NullMean;
        double sd=(double)NullStderr;
        
        double r=StatFunctions.pnorm((x-u)/sd,true);
        if(r==0){return 1e-300;}
        else
        {
            return r;
        }
    }
   
    void RunMA2CScore(String ScoreMethod)
    {
        MA2Cscore= new double[map.probeNum];
        //MedianList = new double[map.probeNum+1];
        RatioMedianList = new double[map.probeNum];
        NearNList = new int[map.probeNum];
        NExcluded = 0;                      // initialization, jssong 1/24/07
        for(int i=0;i<map.probeNum;i++)
        {
           
           RatioMedianList[i]=MyStat.median(getProbeRatios(i));
         
        }
       
        if(ScoreMethod=="Median"){RunMedianList();return;}
        if(ScoreMethod=="MedianPolish"){RunMedianPolish();return;}
        if(ScoreMethod=="TrimmedMean") {RunTrimMean();return;}
        if(ScoreMethod=="PseudoMedian") {RunPseudoMedian();return;}    
    }
    private void RunPvalue()
    /*
     *    must run after RunMA2CScore
     *
     */
    {
        PvalueList= new double[map.probeNum];
        for(int i=0;i<map.probeNum;i++)
        {
          PvalueList[i]=pValue(MA2Cscore[i]);
        }
        
    }
  
   
    /*****************FDRTABLEs************************/
    private void FDRtable()
    {
        double[] NegMA2Cscores = new double[map.probeNum];
        for(int i=0; i<map.probeNum;i++) {
            NegMA2Cscores[i]=2*NullMean-MA2Cscore[i];
        }
        double cut;
        cut=StatFunctions.qnorm(0.01,true)*NullStderr+NullMean;
        ArrayList<FDR> fdr_list= new ArrayList();
        Integer[][] pbed=this._CallPeaks(MA2Cscore,cut);
        Integer[][] nbed=this._CallPeaks(NegMA2Cscores,cut);
        double[] pbed_score=poslist2scorelist(pbed,MA2Cscore);
        double[] nbed_score=poslist2scorelist(nbed,NegMA2Cscores);
        //System.err.println("p="+pbed_score.length);
        //System.err.println("n="+nbed_score.length);
        Arrays.sort(nbed_score);
        
        for(int i=nbed_score.length-1;i>=0;i--)
        {
            cut=nbed_score[i];
        
            int pos;
            int neg;
            double pvaluecut=StatFunctions.pnorm((cut-NullMean)/NullStderr,true);
           /*
            if(i>nbed_score.length-100)
            {
            */
             Integer[][] pbeds=this._CallPeaks(MA2Cscore,cut);
             Integer[][] nbeds=this._CallPeaks(NegMA2Cscores,cut);
             pos=pbeds[0].length;
             neg=nbeds[0].length;
            //System.err.println((nbed_score.length-i)+"\t"+cut+"\t"+neg+"\t"+pos);
            /*
             }
             */
            /*
            else
             
            {
             int c=0;  
             for(int j=0;j<pbed_score.length;j++)
             {
                 if(pbed_score[j]>cut){c++;}
             }
             pos=c;
             neg=nbed_score.length-i;   
            }
             */
            double FDR=100.0*neg/Math.max(1,pos);
            if (FDR > 100.0) {FDR=100.0;}
            if ( FDR>70 && pos>100){break;}
           // System.out.println(FDR+"\t"+cut+"\t"+pvaluecut+"\t"+pos+"\t"+neg);
            FDR fdr=new FDR(FDR,cut,pvaluecut,pos,neg);
            fdr_list.add(fdr);
        }
        fdr_list.trimToSize();
        fdr_table=fdr_list.toArray(new FDR[fdr_list.size()]);
        
    }
    private double[] poslist2scorelist(Integer[][] poslist,double[] score)
    {
        double[] scorelist=new double[poslist[0].length];
        int len=poslist[0].length;
        for(int i=0;i<len;i++)
        {
            //System.err.println(poslist[0][i]+".."+poslist[1][i]);
            scorelist[i]=pos2score(poslist[0][i],poslist[1][i],score);
        }
        return scorelist;
    }
    
    /*
     *  Return max score in the interval
     */
    private double pos2score(int start,int stop,double[] score)
    {
        double max=Double.NEGATIVE_INFINITY;
        for(int i=start;i<=stop;i++)
        {
            if (NearNList[i] < minProbe) continue;
            if(max<score[i]) {max=score[i];}
        }
        return max;
    }
    
    
    private double MA2C2FDR(double MA2C)
    {
         double fdr=Double.MAX_VALUE;
         for(int i=0;i<fdr_table.length;i++)
         {
             if ( fdr_table[i].cut <= MA2C)
             {
                 if( fdr > fdr_table[i].FDR)
                 {
                     fdr=fdr_table[i].FDR;
                 }
                 
                 
             }
         }
       
        
         return fdr;
    }
    public void FDRTablePrint(String fn)
    {
      
        try {
            BufferedWriter f = new BufferedWriter(new FileWriter(fn));
            FDRTablePrint(f);
            f.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        
    }
    private void FDRTablePrint(BufferedWriter f) throws IOException
    {
       f.write("#FDR\tMA2CScore\tPvalue\tPositive\tNegtive\n");
       for(int i=0;i<fdr_table.length;i++)
       {
           String s=fdr_table[i].toString()+"\n";
            
                f.write(s);
           
       }
        
    }
    
    /************************End of FDRTABLES***********************/
    void CallPeaks(String ScoreID, double Threshold)
    {
       ScoreMethod=ScoreID;
       CutOff=Threshold;
       double[] scores = new double[map.probeNum];
       double cutoff=0.0;
       this.FDRtable();
       ArrayList<Bed> BedArrayList = new ArrayList<Bed>();
       for(int i=0; i<map.probeNum;i++)
            {
                scores[i]=MA2Cscore[i];
            }
        
        if (ScoreID.equalsIgnoreCase("FDR"))
        {
           int i;
           for(i=0;i<fdr_table.length;i++)
           {
               
               if(fdr_table[i].FDR>Threshold){break;}
           }
           //int index=Math.max(i-1,0);
           if(i>0)
           {
           cutoff=fdr_table[i-1].cut;
           //System.err.println(fdr_table[i-1].FDR+" cutoff:"+cutoff+"\t"+"FDR:"+Threshold);
           } 
           else
           {
               cutoff=fdr_table[i].cut;
           }
       }
        if (ScoreID.equalsIgnoreCase("Pvalue"))
        {
           //  System.out.println("in pvalue");
           // add source code to change the pvalue to ma2cscore cutoff
           //using NullMean and NullStderr
           cutoff=NullMean+NullStderr*StatFunctions.qnorm(Threshold,true);
        }
      
        if (ScoreID.equalsIgnoreCase("MA2C"))
        {
            cutoff=Threshold;            
        }
       Integer a[][];
       a=_CallPeaks(scores,cutoff);
       //PeakStart=a[0];PeakStop=a[1];
       for(int i=0;i<a[0].length;i++)
       {
           Bed bed = _ProbePosToBed((int)a[0][i],(int)a[1][i],scores);
           bed.ID= new String();
           bed.ID=this.Name+"_p"+Integer.toString(i);
           bed.negative_or_positive=1;
           //System.out.println(bed.toXlsString());
           BedArrayList.add(bed);
       }
       
       for(int i=0; i<map.probeNum;i++)
            {
                scores[i]=2*NullMean-MA2Cscore[i];
            } 
       //cutoff= cutoff-2*NullMean;
       a=_CallPeaks(scores,cutoff);
       for(int i=0;i<a[0].length;i++)
       {
           Bed bed = _ProbePosToBed((int)a[0][i],(int)a[1][i],scores);
           bed.ID= new String();
           bed.ID=this.Name+"_n"+Integer.toString(i);
           bed.negative_or_positive=-1;
           bed.Pvalue=1.0-bed.Pvalue;
           if(bed.Pvalue==0.0){bed.Pvalue=1.0e-300;}
           //System.out.println(bed.toXlsString());
           BedArrayList.add(bed);
       }
       BedArrayList.trimToSize();
       BedArray=BedArrayList.toArray(new Bed[BedArrayList.size()]);
       
       BedFDR();
    }
   private void BedFDR()
   {
      
       for(int i=0;i<BedArray.length;i++)
       {
          BedArray[i].FDR=MA2C2FDR(BedArray[i].Score);
         
         
          //System.err.println(BedArray[i].MA2CScore+"\t"+BedArray[i].FDR);
       }
       
   }
     /*
     * Returns True if the distance between no1 and no2 probes is <= maxGap
     */
    private boolean isInRegion(int no1,int no2)
    {
        if (no2 < 0 || no1 < 0) 
          {
            return false;
          }
        if (no2 >= map.Start.length || no1 >= map.Start.length)
        {
            return false;
        }
        if (map.Chr[no1]!=map.Chr[no2]) {return false;}
        else if (Math.abs(map.Start[no1]+map.Len[no1]/2-(map.Start[no2]+map.Len[no2]/2))> maxGap) {
            return false;
        }
        else 
        {
            return true;
        }
                
    }
    private Integer[][] _CallPeaks(double[] Scores,double Threshold)
    {
        //System.out.println("Calling Peaks....");
        ArrayList<Integer> PeakStartList = new ArrayList();
        ArrayList<Integer> PeakStopList = new ArrayList();
       
        //ScoreMethodThreshold=ScoreID+">"+Float.toString(Threshold);
        //setPeakScore(ScoreID,(double)Threshold);  
        for(int i=0;i<map.probeNum;i++)
        {
            if (NearNList[i] < minProbe) continue; // too few probes in the window to start a new region
                                                   // jssong 1/24
            else{
                if (Scores[i] > Threshold) {

                     int start=i;
                     int stop=i;
                     int j = i+1;                          // jssong 1/24

                     while(isInRegion(stop,j))               // jssong 1/24
                     {
                         if(NearNList[j] >= minProbe && Scores[j] > Threshold)         // jssong 1/24
                         {
                             stop=j;                       // jssong 1/24
                         }
                         j++;                              // jssong 1/24
                     }

        //             double score_median=ScoreMedian(Scores,start,stop);
        //             
        //             while(isNearby(start,start-1) && start-1>=0 && Scores[start-1]>score_median)
        //             {
        //                 start--;
        //             }
        //             
        //             while(isNearby(stop,stop+1) && stop+1<=Scores.length-1 && Scores[stop+1]>score_median)
        //             {
        //                stop++;
        //             }

                     PeakStartList.add(start);
                     PeakStopList.add(stop);
                     i=stop;//
                }
            }
            
            
        }
        Integer[] myPeakStart=(Integer[]) PeakStartList.toArray(new Integer[PeakStartList.size()]);
        Integer[] myPeakStop=(Integer[]) PeakStopList.toArray(new Integer[PeakStopList.size()]);        
        Integer[][] myReturn=new Integer[2][];
        myReturn[0]=myPeakStart;
        myReturn[1]=myPeakStop;
        return myReturn;
    }
   private double ScoreMedian(double[] scores,int start,int stop)
   {
        int L = stop-start+1;
        double[] a= new double[L];
        double median;
        for(int i=start;i<=stop;i++)
        {
            a[i-start]=scores[i];
            
        }
        median=MyStat.median(a,L);
        return median;
   }
   private Bed _ProbePosToBed(int probe_start,int probe_stop,double[] scores)
    {
        String bedChr=map.ChrID[map.Chr[probe_start]];
        //long bedStart=map.ProbeMiddle[PeakStart[i]]-band_length;
        //long bedStop=map.ProbeMiddle[PeakStop[i]]+band_length;
        long bedStart=map.Start[probe_start]-band_length;                        // jssong 1/24/07
        long bedStop=map.Start[probe_stop]+map.Len[probe_stop]-1 + band_length;  // jssong 1/24/07
        if (bedStart<0){bedStart=1;}
        Double bedScore=0.0;
        int PeakPos=probe_start;
        Bed a=null;
        
        // find the probe with max MA2C score
        for(int j=probe_start;j<=probe_stop;j++){      
            if (NearNList[j] >= minProbe && scores[PeakPos] < scores[j]) {PeakPos=j;}
        }

        long PeakRelativePos= ( (bedStart + bedStop)/2  + map.ProbeMiddle[PeakPos])/2 - bedStart +1 ;
        long Length=bedStop-bedStart+1;
        double P=-Math.log10(PvalueList[PeakPos])*10;
        int ProbeNumber=probe_stop-probe_start+1;
        bedScore=scores[PeakPos];

        a = new Bed(bedChr,bedStart,bedStop,bedScore);
        a.Pvalue=PvalueList[PeakPos];
        a.ProbeNumber=ProbeNumber;
        a.PeakPos=(int)PeakRelativePos;
        a.MA2CScore=MA2Cscore[PeakPos];
        a.len=(int)Length;
        a.ProbeStart=probe_start;
        a.ProbeStop=probe_stop;
        return a;
    }
   /*
    private double RatioMedian(int start,int stop)
    {
        int L = stop-start+1;
        double[] a= new double[L];
        double median;
        for(int i=start;i<=stop;i++)
        {
            a[i-start]=RatioMedianList[i];
            
        }
        median=MyStat.median(a,L);
        return median;
    }
    */
    public void Run(String ScoreMethod)
    {
     //   RunMedianList();
        RunMA2CScore(ScoreMethod);
        RunNullList();
        
        RunPvalue();
     
    }
    
    void BedPrinter(String Filename) 
    {
        FileWriter out = null;
        try {
            out = new FileWriter(Filename);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
       BedPrinter(out);
        try {
           
            out.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
       
    }
    void BedPrinter(FileWriter output)
    {
        BedPrinter(output,1);
    }
    void BedPrinter(FileWriter output,int NegPos)
    {
        try {
  
            output.write("#Chr\tStart\tStop\tPeakID\tMA2Cscore\n");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
      
        String prevChr= "";             // jssong 2/18/07
        long prevStop= -1;              // jssong 2/18/07
        DecimalFormat myFormatter= new DecimalFormat("###.#####");
        for(int i=0;i<BedArray.length;i++)
        {
        try{
           if(BedArray[i].negative_or_positive==NegPos)
            {   
               Bed thisBed = BedArray[i];
               if (prevChr.equals(BedArray[i].Chr)){
                   if (prevStop >= thisBed.Start){
                        String str=thisBed.Chr+"\t"+Long.toString(prevStop +1)+"\t"+Long.toString(thisBed.Stop)+"\t"+thisBed.ID+"\t"+myFormatter.format(thisBed.Score);
                        output.write(str +"\n");
                   } else{
                       output.write(thisBed.toString()+"\n");
                   }
               } else{
                   output.write(thisBed.toString()+"\n");
               }
               
               prevChr = thisBed.Chr;
               prevStop = thisBed.Stop;
            
            }
           } 
            
            catch(IOException Ex)
        {
        }
        }
        try {
                output.flush();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
    
    }
     void BedXlsPrinter(FileWriter output)
     {
         BedXlsPrinter(output,1);
     }
     void BedXlsPrinter(FileWriter output,int PosNeg)
    {
      double max_fdr=0.0;   
      double min_score=Double.MAX_VALUE;
      for(int i=0;i<BedArray.length;i++)
      {
     
    
        if(PosNeg==BedArray[i].negative_or_positive)
        {
           if(max_fdr < BedArray[i].FDR) {max_fdr=BedArray[i].FDR;}
           if(min_score > BedArray[i].MA2CScore){min_score=BedArray[i].MA2CScore;}
        }
        
      }
         
        try {
            output.write("#Chr\tStart\tEnd\tPeakID\tScores\t-10*log10Pvalue\tMA2Cscore\tFDR(%)\tPeak_Pos\tLength\t#Probes\n");
            output.write("# Cutoff: "+ScoreMethod+"\t"+CutOff+"\n");
            output.write("# BandWidth="+band_length+"\n");
            output.write("# MaxGap="+maxGap+"\n");
            output.write("# MinProbe="+minProbe+"\n");
            output.write("# Null: mhat="+NullMean+" sigmahat="+NullStderr+"\n");
            output.write("# Number of excluded probes="+NExcluded+"\n");
            //output.write("# MAT_Score: max="+"");
            output.write("# FDR:"+max_fdr+"%\n");
            output.write("# Tpmap: "+this.map.filename+"\n");
            output.write("# Normalized_data_file:"+"\n");
            for(int i=0;i<filenames.length;i++)
            {
            output.write("#  "+filenames[i]+"\n");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
      for(int i=0;i<BedArray.length;i++)
      {
        try
        {
        if(PosNeg==BedArray[i].negative_or_positive)
        {
        output.write(BedArray[i].toXlsString()+"\n") ;   
        }
        } catch(IOException Ex)
        {
        }
      }
        try {
                output.flush();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        
    }
     
    void ProbePrinter()
    {
        
    }
//    public void draw_histograms()
//    {
//        double[][] b=new double[4][];
//        b[0]=MedianList;
//        b[1]=MA2Cscore;
//        b[2]=PvalueList;
//  
//        b[3]=RatioMedianList;
//        
//        GraphManager.showHistograms(b, 10000, new String[]{"MedianList","MA2Cscore","Pvalue","RatioList(Median)"});
//        
//    }
    
    public void draw_histograms(String outfilename, String info)
    {
        double[][] b=new double[3][];
        int newDim = map.probeNum-NExcluded;
        double[] graph_MA2C = new double[newDim];
        double[] graph_PValue = new double[newDim];
        double[] graph_Ratio = new double[newDim];
        
        int j =0;
        for(int i =0; i < map.probeNum ; i++){
            if (NearNList[i] >= minProbe){
                graph_MA2C[j] = MA2Cscore[i];
                graph_PValue[j] = PvalueList[i];
                graph_Ratio[j] = RatioMedianList[i];
                j++;
            }
        }
        b[0]=graph_MA2C;
        b[1]=graph_PValue;
        b[2]=graph_Ratio;   
        
        // Build FDR table
        int nFDR = fdr_table.length;
        double[][] fdrdata = new double[nFDR][2];
        for (int i = 0; i < nFDR; i ++){
            fdrdata[i][0] = fdr_table[i].FDR;
            fdrdata[i][1] = fdr_table[i].pos -fdr_table[i].neg;
        }
        GraphManager.showHistogramsAndFDR(b, 10000, new String[]{"MA2Cscore","Pvalue","RatioList(Median)","FDR Table"}, fdrdata,info, outfilename);
        
        
    }
    public int getNExcluded(){
        return NExcluded;
    }
    public  void save_to_barfile(String outfilename,String ScoreID)
    {
        BarFileData a=new BarFileData();
        a.SetFileName(outfilename);
        a.AddAlgorithmParameter("program","MA2C");
        a.AddAlgorithmParameter("ScoreID",ScoreID);
        //String chr="chr1";
        //String version="test";
        //String group="hg";
        //int[] p=new int[]{2,3};
        //float[] v=new float[]{3.0f,4.0f};
        
        int last=0;
        for (int i=0;i<this.map.ChrNum;i++)
        {
         int length=this.map.ChrIndex[i+1]-last;
         int[] p= new int[length];
         float[] v= new float[length];
         String chr=this.map.ChrID[i];
         String version="";// change it later
         String group=""; //change it later
         for(int j=0;j<length;j++)
         {
             p[j]=(int)map.ProbeMiddle[j+last];
            if(ScoreID.equalsIgnoreCase("MA2Cscore"))
            {
             v[j]=(float)this.MA2Cscore[j+last];
            }
            else if(ScoreID.equalsIgnoreCase("RatioMedian"))
            {
             v[j]=(float)this.RatioMedianList[j+last];
            }
            else if(ScoreID.indexOf("Ratio_")==0)
            {
                 String[] r=ScoreID.split("_");
                 int k=Integer.valueOf(r[1]);
                 v[j]=(float)(double)RatioLists[k][j+last];
            }
            
         }
         //System.err.println(map.Chr[length-1+last]+"\t"+map.ProbeMiddle[length-1+last]+"\t"+map.Chr[length+last]+"\n");
         //System.err.println(i+"\t"+chr+"\t"+version+"\t"+group+"\t"+p.length);//debug
         BarSequenceItem b=new BarSequenceItem(chr,version,group,p,v);
        
        last=this.map.ChrIndex[i+1];
        
         a.AddSequenceItem(b);
        
        }
       // a.AddSequenceItem(b);
        try {
            //System.out.println("saving a now.");
           //System.out.println(a.GetVersion());
            a.Save();
        } catch (IOException ex) {
            //System.err.println("error in saving bar file");
            ex.printStackTrace();
        }
        
    }
    public static void main(String[] args)
    {
        //String map_fn="/Users/zhuxp/NimbleGenData/MA2C_1702.bpmap";
        //String ratio_fn="/Users/zhuxp/NimbleGenData/MA2C_43820_normalized.txt";        
        //RunPeak e=new RunPeak(map_fn,ratio_fn);
        
        RunPeak e=new RunPeak();
        //e.ReadGFF("/Users/zhuxp/86692.gff");
        System.out.println("start run");
        
        e.Run("Median");
        e.CallPeaks("Qvalue",5.0F);
        FileWriter out;
        try {
            out = new FileWriter("/Users/zhuxp/test.out");
            //e.BedDetailPrinter(out); 
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        //e.PeakPrinter();
            
            
       
     }
 }
    


    
    


