/*
 * Main.java
 *
 * Created on April 27, 2006, 12:21 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 *
 * GUI for MAT
 * jssong
 */

package MA2C;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.io.File;
import java.util.PropertyResourceBundle;

/**
 *
 * @author jssong
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
        new WelcomePanel().setVisible(true);
        
        //new NimbleContolPanel().setVisible(true);
    }
    public Main(String path) {
        new NimbleControlPanel(path).setVisible(true);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       if (args.length == 0 ){
           new Main();
       } else{
           System.out.println("Test");
       }
     
        
    }
    
}
