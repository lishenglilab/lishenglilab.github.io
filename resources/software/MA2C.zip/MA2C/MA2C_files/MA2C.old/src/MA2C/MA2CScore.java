/*
 * MA2CScore.java
 *
 * Created on 2007�~1��5��, �W�� 11:27
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

/**
 *
 * @author hesm
 */
public class MA2CScore {
    
    /** Creates a new instance of MA2CScore */
    public MA2CScore() {
    }
    /*
     *  MedianPolish Matrix 
     *  and return mean of each row
     *  IMPORTANT:
     *   the original matrix will change after polishing.
     *
     */
    
    public static double[] MedianPolish(double[][] matrix) {
        int row_num = matrix.length;
        int col_num=matrix[0].length;
        double[] means = new double[row_num];
        double[][] mat = new double[row_num][col_num];
        for(int i=0;i<row_num;i++)
        {
            for(int j=0;j<col_num;j++)
            {
            mat[i][j]=matrix[i][j];
            }
        }
        //PrintMat(mat);
        do
        {
            double[] rows_median=RowMedian(mat);
           
            for(int i=0;i<row_num;i++)
            {
                for(int j=0;j<col_num;j++)
                {
            //     System.out.print(mat[i][j]+"-"+rows_median[i]+" "); 
                 mat[i][j]=mat[i][j]-rows_median[i];   
                     
                }
                //System.out.println();
            }
       
            double[] cols_median=ColMedian(mat);
            for(int i=0;i<row_num;i++)
            {
                for(int j=0;j<col_num;j++)
                {
                 mat[i][j]=mat[i][j]-cols_median[j];   
                }
            }
            int signal=0;
            for(int i=0;i<rows_median.length;i++)
            {
                if (rows_median[i]!=0) {signal=1;break;}
            }
            for(int i=0;i<cols_median.length;i++)
            {
                if(cols_median[i]!=0) {signal=1;break;}
            }
            if(signal==0){break;}
          //  PrintMat(mat);
            //System.out.println("->");
        }
        while(true);
        //System.out.println("matrix:");
        //PrintMat(matrix);
        for(int i=0;i<row_num;i++)
        {
            means[i]=0.0d;
            for(int j=0;j<col_num;j++)
            {
              matrix[i][j]=matrix[i][j]-mat[i][j];  
              means[i]=means[i]+matrix[i][j];
            }
            means[i]=means[i]/col_num;
        }
        
        return means;
    }
    
    private static double[] RowMedian(double[][] mat)
    {
        int row_number = mat.length;
        double[] row_medians = new double[row_number];
        for(int i=0;i<row_number;i++)
        {
            row_medians[i]=MyStat.median(mat[i],mat[i].length);
           
        }
        
        return row_medians;
    }
    private static double[] ColMedian(double[][] mat)
    {
        int col_number=mat[0].length;
        int row_number=mat.length;
        double[] col_medians = new double[col_number];
        for(int j=0; j < col_number; j++)
        {
            double[] col = new double[row_number];
            for(int i=0;i<row_number;i++){col[i]=mat[i][j];}
            col_medians[j]=MyStat.median(col,col.length);
        }
        return col_medians;
        
    }
    public static double MedianOfMedianPolish(double[][] mat)
    {
        double[] means=MedianPolish(mat);
        return MyStat.median(means,means.length);
    }
    public static double MeanOfMedianPolish(double[][] mat)
    {
        double[] means=MedianPolish(mat);
        return MyStat.mean(means);
        
    }
    /*
     *  this function is
     *  useless for less than 3 duplicates
     *  just leave here in case that anyone come up with any idea;
     */
    public static double TrimMeanOfMedianPolish(double[][] mat)
    {
        double[] means=MedianPolish(mat);
        return MyStat.trimmean(means);
    }
    
    private static void PrintMat(double[][] mat)
    {
        System.out.println("Matrix:");
        int row_num=mat.length;
        int col_num=mat[0].length;
        for(int i=0;i<row_num;i++)
        {
            for(int j=0;j<col_num;j++)
            {
                System.out.print(mat[i][j]+" ");
            }
            System.out.println();
        }
    }
    
    private static void PrintArray(double[] array)
    {
        System.out.println("Array:");
        int num=array.length;
        for(int i=0;i<num;i++)
        {
          System.out.print(array[i]+" ");    
        }
        System.out.println();
    }

    
    

    public static double TrimMeanInBand(double[][] mat)
    {
        int row_num=mat.length;
        int col_num=mat[0].length;
        double m=0.0d;
        for(int i=0;i<row_num;i++)
        {
            m=m+MyStat.trimmean(mat[i]);
        }
        return m/row_num;
    }
    
    
    public static double MedianInBand(double[][] mat)
    {
        int row_num=mat.length;
        int col_num=mat[0].length;
        double[] a=new double[row_num*col_num];
        for(int i=0;i<row_num;i++)
        {
            for(int j=0;j<col_num;j++)
            {
                a[i*col_num+j]=mat[i][j];
                
            }
        }
        return MyStat.median(a,a.length);
    }
    public static double PseudoMedianInBand(double[][] mat)
    {
        
        int row_num=mat.length;
        int col_num=mat[0].length;
        int total_num=row_num*col_num;
        double[] a=new double[row_num*col_num];
        for(int i=0;i<row_num;i++)
        {
            for(int j=0;j<col_num;j++)
            {
                a[i*col_num+j]=mat[i][j];
                
            }
        }
        
        
        return MyStat.pseudomedian(a);
    }
 
    public static void main(String[] args)
    {
        double[][] a=
                         { 
                   {4.0d,3.0d,6.0d,4.0d,7.0d},
                   {8.0d,1.0d,10.0d,5.0d,11.0d},
                   {6.0d,2.0d,7.0d,8.0d,8.0d},
                   {9.0d,4.0d,12.0d,9.0d,12.0d},
                   {7.0d,5.0d,9.0d,6.0d,10.0d},
                   
                         };
        
        PrintMat(a);
        System.out.println();
        
        double[] means=MedianPolish(a);
        PrintMat(a);
        
        PrintArray(means);
        
    }
}
