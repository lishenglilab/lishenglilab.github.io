/*
 * FileChecker.java
 *
 * Created on July 27, 2006, 11:25 PM
 *
 */

package MA2C;
import java.io.*;
import java.util.Hashtable;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Enumeration;

/**
 *
 * @author jssong
 */
public class FileChecker {
    
    final String PREFIX = "MA2C_";
    File seqFolder = null;
    File dataFolder = null;
    String seqFolderPath = "";
    String dataFolderPath = "";
    String[] design;
    String[][] IP;
    FileWriter fw;
    
    /** IP contains CHIP_ID, IP dye, Input Dye, DESIGN_ID */
    public FileChecker(File seqFolder, File dataFolder, String[] design, String [][] IP, FileWriter fw) {
        this.seqFolder = seqFolder;
        this.dataFolder = dataFolder;
        this.design = design;
        this.IP = IP;
        this.seqFolderPath = seqFolder.getAbsolutePath() + File.separator;
        this.dataFolderPath = dataFolder.getAbsolutePath() + File.separator;
        this.fw = fw;
    }
    
    /** Check whether .tpmap files exist for the chosen DESIGN_ID'ss.
     *  If not, then create them using .ndf and .pos files.
     */
    public String checkSeq(){
        String message ="";
        String[] files = seqFolder.list();
        ArrayList<String> needtpmap = new ArrayList<String>(1); // Array of DESIGN_ID without tpmap
        // For each DESIGN_ID, check that a tpmap file exists; if not, store the ID in need tpmap
        for (int i =0;  i < design.length; i ++){
            boolean hastpmap = false;
            String lookfor = PREFIX + design[i] + ".tpmap";     // Name of tpmap file
            //print(lookfor);
            for (int j = 0; j < files.length; j ++){
                if (files[j].equals(lookfor)){
                    hastpmap = true;
                    break;
                }
            }
            if (!hastpmap){
                needtpmap.add(design[i]);
            } else{
                message += "\tFound: "+lookfor +"\n";
            }
        }
        needtpmap.trimToSize();
        
            
        if (needtpmap.size() == 0){                             // tpmap already exists; just read the file
            
        }else{                                                  // else, create a new tpmap file
            Vector fileinfo = new Vector();
            String[] messages = checkNdfPos(fileinfo, needtpmap.toArray(new String[needtpmap.size()]));
                                                                // Get pairs of .ndf and .pos files.
                                                                // .pos might not exist.
            try{
                createtpmap(fileinfo);
            } catch(IOException e){
                
            }
            //print(messages);
            message += messages[1];
        }
        try{
            fw.write(message+"\n");
            fw.flush();
        } catch(IOException e){
            System.err.print("Cannot write to a log file.");
        }
        
        return message;
    }

    private void createtpmap(Vector ndfPosFiles) throws IOException{
        for (int i =0; i < ndfPosFiles.size(); i ++) {
            String[] f = (String []) ndfPosFiles.elementAt(i);
            String newFileName = PREFIX + f[0] + ".tpmap";
            String ndfFileName  = f[1];
            String posFileName = f[2];
            
            fw.write("Creating " + newFileName+"\n");
            
            if (!posFileName.equals("")){                       // .pos file exists; get coordinates from there
                int[] dimension = new int[2];
                Hashtable NDF = getNDF(ndfFileName, false, dimension);                
                String[][] pos = getPositions(posFileName); //String[]{l[CHROMOSOME], l[POSITION], l[SEQ_ID], l[PROBE_ID]})
                FileWriter tpmap = new FileWriter(new File(seqFolderPath + newFileName));
                tpmap.write("#seq_group_name " +f[0]+"\n");
                tpmap.write("#XYdimension\t" + dimension[0] + "\t"+dimension[1]+"\n");
                int nLines = pos.length;
                //System.out.println(nLines);
                
                
                for(int k = 0; k < nLines; k++){
                    String[] line = pos[k];
                    String SEQID = line[2];
                    String PROBEID = line[3];
                    String[] info = (String []) ((Hashtable) NDF.get(SEQID)).get(PROBEID);
                    
                    // SEQ, strand, chr, start, x,y
                    String out = info[0]+"\t0\t"+ line[0] +"\t"+line[1]+ "\t"+ info[1] +"\t"+info[2] +"\n";
                    tpmap.write(out);
                }
                tpmap.close();
                System.gc();
            } else{                                             // .pos file doesn't exist; use SEQ_ID and POSITION in .ndf
                int[] dimension = new int[2];
                Hashtable NDF = getNDF(ndfFileName, true, dimension);
                FileWriter tpmap = new FileWriter(new File(seqFolderPath + newFileName));
                tpmap.write("#seq_group_name " +f[0]+"\n");
                tpmap.write("#XYdimension\t" + dimension[0] + "\t"+dimension[1]+"\n");
                
                for (Enumeration e = NDF.keys() ; e.hasMoreElements() ;) {
                    String seqidname = (String) e.nextElement();
                    ArrayList<String[]> a = (ArrayList) NDF.get(seqidname);
                    
                    String[][] info =  a.toArray(new String[a.size()][4]);
                    UtilityFunctions.sort2(info);
                    int nLines = info.length;
                    String out ="";
                    for (int k =0; k < nLines; k ++){
                        out = info[k][1] +"\t0\t"+ seqidname + "\t" + info[k][0] +  "\t"+ info[k][2] +"\t"+info[k][3] +"\n";
                        tpmap.write(out);
                        tpmap.flush();
                    }
//                    tpmap.write(out);
//                    tpmap.flush();
                   
                }
                tpmap.close();
                System.gc();
            }
            System.gc();
        }
    }
    
    /** Read an .ndf file and get sequence info **/
    private Hashtable getNDF(String ndfFile, boolean includepos, int[] dimension){
        boolean excludepos = (!includepos);
        Hashtable seqinfo = new Hashtable();
        try{
            int xMax = 0;
            int yMax = 0;
            BufferedReader f = new BufferedReader (new FileReader(ndfFile));
            String line;
            
            int PROBE_ID=0,SEQ_ID=0, X =0,Y=0,PROBE_SEQUENCE=0, POSITION=0, CONTAINER = 0;
            // Get column indices
            while ( (line =f.readLine())!= null) {
                if (line.trim().indexOf("#") == 0) continue;
                else{
                    String[] header = line.split("\t");
                    for (int j = 0; j < header.length; j ++){
                         if (header[j].trim().equals("PROBE_ID")) PROBE_ID = j;
                         else if (header[j].trim().equals("SEQ_ID")) SEQ_ID = j;
                         else if (header[j].trim().equals("PROBE_SEQUENCE")) PROBE_SEQUENCE = j;
                         else if (header[j].trim().equals("X")) X = j;
                         else if (header[j].trim().equals("Y")) Y = j;
                         else if (header[j].trim().equals("POSITION")) POSITION = j;
                         else if (header[j].trim().equals("CONTAINER")) CONTAINER = j;
                    } 
                    break;
                }
            }
            
            // Store data in a hashtable
            while ( (line =f.readLine())!= null) {
                String[] l = line.split("\t");
                String SEQID = l[SEQ_ID].trim();
                String PROBEID = l[PROBE_ID].trim();
                String CONTAINER_INFO = l[CONTAINER].trim();
                if (includepos && (CONTAINER_INFO.equalsIgnoreCase("RANDOM") || CONTAINER_INFO.indexOf("NGS_CONTROL") >= 0  
                        || CONTAINER_INFO.indexOf("ECOLI") >= 0)) continue;
                int xloc = Integer.parseInt(l[X]);
                int yloc = Integer.parseInt(l[Y]);
                if (xloc > xMax) xMax = xloc;
                if (yloc > yMax) yMax = yloc;
                
                if(!seqinfo.containsKey(SEQID)){
                    if (excludepos) seqinfo.put(SEQID, new Hashtable());
                    else seqinfo.put(SEQID, new ArrayList<String[]>());
                }
                if(includepos) ((ArrayList)seqinfo.get(SEQID)).add(new String[]{l[POSITION],l[PROBE_SEQUENCE], l[X], l[Y]});
                else ((Hashtable)seqinfo.get(SEQID)).put(PROBEID, new String[]{l[PROBE_SEQUENCE], l[X], l[Y]});
            }
            f.close();
            dimension[0] = xMax;
            dimension[1] = yMax;
        } catch(IOException e){
            
        }
        
        return seqinfo;
    }
    
    /** Read a .pos file and return data sorted by chromosome **/
    private String[][] getPositions(String posFile){
        ArrayList<String[]> S = new ArrayList<String[]>(30000);
        try{
            BufferedReader f = new BufferedReader (new FileReader(posFile));
            String line;
            
            int PROBE_ID=0,SEQ_ID=0,CHROMOSOME=0,POSITION=0;

            while ( (line =f.readLine())!= null) {
                if (line.trim().indexOf("#") == 0) continue;
                else{
                    String[] header = line.split("\t");
                    for (int j = 0; j < header.length; j ++){
                         if (header[j].trim().equals("PROBE_ID")) PROBE_ID = j;
                         else if (header[j].trim().equals("SEQ_ID")) SEQ_ID = j;
                         else if (header[j].trim().equals("CHROMOSOME")) CHROMOSOME = j;
                         else if (header[j].trim().equals("POSITION")) POSITION = j;
                    } 
                    break;
                }
            }
            while ( (line =f.readLine())!= null) {
                String[] l = line.split("\t");
                S.add(new String[]{l[CHROMOSOME], l[POSITION], l[SEQ_ID], l[PROBE_ID]});
            }
            f.close();
            
        } catch(IOException e){
            
        }
        
        S.trimToSize();
        String[][] lines = S.toArray(new String[S.size()][4]);
        UtilityFunctions.sort(lines);                       // Sort by chromosome and then by position
        return lines;
    }
    
  
    
    /** Called when a tpmap file doesn't exist.
     *  Checks for correct .ndf and .pos files.
     **/
    private String[] checkNdfPos (Vector fileinfo, String[] needtpmap ){
        String[] messages = new String[2];                  // messages[0] = error message
        messages[0] = messages[1] = "";                     // messages[1] = log 
        
        FilenameFilter filter = new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.endsWith(".ndf");
            }
        }; 
        String[] ndfFiles = seqFolder.list(filter);         // Get all .ndf files
        Hashtable ht = new Hashtable();
        boolean error = false;
        
        /** Read the DESIGN_ID of all .ndf files **/
        for (int i = 0; i < ndfFiles.length; i ++){
            String designID="";
            String filename = seqFolderPath + ndfFiles[i];
            try{
                int thisdesignIDIndex=-1;
                BufferedReader f = new BufferedReader (new FileReader(filename));
                String line;
                        
                while ( (line =f.readLine())!= null) {
                    if (line.trim().indexOf("#") == 0) continue;
                    else{
                        
                        String[] header = line.split("\t");
                        for (int j = 0; j < header.length; j ++){
                             if (header[j].trim().equals("DESIGN_ID")) thisdesignIDIndex = j;
                        } 
                        break;
                    }
                }
                if (thisdesignIDIndex == -1 ) continue;
                designID = f.readLine().split("\t")[thisdesignIDIndex].trim();
                ht.put(designID,filename);
                f.close();
            } catch (IOException io){
                System.err.print("Cannot open " + filename );
                messages[0] = "Cannot open " + filename;
                return messages;
            }
            //updateTextArea2(designID);
        }
        
        /** Check that the chosen IP's have corresponding .ndf files **/
        for (int i = 0; i < needtpmap.length; i ++){
            String sampleDesignID = needtpmap[i];
            String[] f = new String[3];
           
            if (ht.containsKey(sampleDesignID)){
                
                f[0] = sampleDesignID;
                f[1] = (String) ht.get(sampleDesignID);
                
                File posFile = new File(f[1].split(".ndf")[0] +".pos");
                
                
                // Check whether a .pos file exists for this .ndf file 
                if (posFile.exists()) {
                    f[2] = posFile.getAbsolutePath();
                    messages[1] += "\tCreated: "+ PREFIX + sampleDesignID+".tpmap from\n\t\t" + f[1] +"\n\t\t"+f[2] +"\n";
                }
                else {
                    f[2] = "";
                    messages[1] += "\tCreated: "+ PREFIX + sampleDesignID+".tpmap from\n\t\t" + f[1] +"\n";
                }
                fileinfo.add(f);
            } else{
                error = true;
                messages[0] ="ERROR\nSequence file not found for CHIP_ID " + sampleDesignID + "\n";
                return messages;
            }
            
        }
        return messages;
    }
    
    public String checkRawData(){
        String message ="";
        String[] files = dataFolder.list();
        ArrayList<String[]> needRaw = new ArrayList<String[]>(1); 
        // For each IP, check that a combined raw data file exists; if not, then prepare for creating the files
        for (int i =0;  i < IP.length; i ++){
            boolean hasRaw = false;
            String lookfor = PREFIX + IP[i][0] + "_raw.txt"; // 
            //print(lookfor);
            for (int j = 0; j < files.length; j ++){
                if (files[j].equals(lookfor)){
                    hasRaw = true;
                    break;
                }
            }
            if (!hasRaw){
                needRaw.add(IP[i]);
            } else{
                message+= "\tFound: " + lookfor + "\n";
            }
        }
        needRaw.trimToSize();
        
            
        if (needRaw.size() == 0){                                  // 
        }else{                                          // Create  raw pair data files.
            Vector fileinfo = new Vector();             // Each element = array of IP and Input files to be combined
            String[] messages = checkDataFolder(fileinfo, needRaw.toArray(new String[needRaw.size()][4]));
            createRawDataPair(fileinfo);
            //print(messages);
            message += messages[1];
        }
        try{
            fw.write(message+"\n");
            fw.flush();
        } catch(IOException e){
            System.err.print("Cannot write to a log file.");
        }
        return message;
    }
    
    /**  Determine which SAMPLES require combined raw.txt files */
    private String[] checkDataFolder(Vector fileinfo, String[][] needRaw ){
        String[] messages = new String[2];                  // messages[0] = error message
        messages[0] = messages[1] = "";                     // messages[1] = log 
        
        FilenameFilter filter = new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.endsWith(".txt") || name.endsWith(".pair");
            }
        }; 
        String[] dataFiles = dataFolder.list(filter);         // Get all .ndf files
        Hashtable ht = new Hashtable();
        boolean error = false;
        
        /** Read the IMAGE_ID of all .data files **/
        for (int i = 0; i < dataFiles.length; i ++){
            String imageID="";
            String designID ="";
            String filename = dataFolderPath + dataFiles[i];
            try{
                int imageIDIndex=-1;                
                BufferedReader f = new BufferedReader (new FileReader(filename));
                String line;
                        
                while ( (line =f.readLine())!= null) {
                    if (line.trim().indexOf("#") == 0) continue;
                    else{
                        
                        String[] header = line.split("\t");
                        for (int j = 0; j < header.length; j ++){
                             if (header[j].trim().equals("IMAGE_ID")) imageIDIndex = j;
                        } 
                        break;
                    }
                }
                
                if (imageIDIndex == -1 ) continue;              // IMAGE_ID not found, continue with next file
                imageID = f.readLine().split("\t")[imageIDIndex].trim();
                ht.put(imageID, filename);
                f.close();
            } catch (IOException io){
                System.err.print("Cannot open " + filename );
                messages[0] = "Cannot open " + filename;
                return messages;
            }
            //updateTextArea2(designID);
        }
        /** Check that the chosen IP's have corresponding data files **/
        for (int i = 0; i < needRaw.length; i ++){
            String[] f = new String[4];
            // f[0] = CHIP_ID
            // f[1] = IP file
            // f[2] = Input file
            // f[3] = DESIGN_ID
            
            f[0] = needRaw[i][0];            
            for (int n = 1; n < 3; n ++){       // loop over IP and INPUT Dyes
                String sampleID = needRaw[i][0]+"_"+needRaw[i][n];
                
                if (ht.containsKey(sampleID)){
                    f[n] =  (String) ht.get(sampleID);;        // Name of the single channel file
                    f[3] =  needRaw[i][3];        // DESIGN_ID
                    if (n == 1) messages[1] += "\tCreated: "+ PREFIX + sampleID+"_raw.txt\n";
                    
                } else{
                    messages[0] ="ERROR\nData file not found for CHIP_ID " + sampleID + "\n";
                    return messages;
                }
            }
            fileinfo.add(f);
            
            
        }
        return messages;
    }
    
    
    /** Create raw.txt files from pairs of IP and Input files
     *  dataFiles contains CHIP_ID, IP file, Input file, DESIGN_ID
     */
    private void createRawDataPair (Vector dataFiles) {
        try{
            Hashtable tpmapOrder = new Hashtable();
             for (int i =0; i < dataFiles.size(); i ++) {
                String[] f = (String []) dataFiles.elementAt(i);
                String newFileName = dataFolderPath+PREFIX + f[0] +"_raw.txt";
                String IPFileName = f[1];
                String InputFileName = f[2];
                String DESIGNID = f[3];
                if (!tpmapOrder.containsKey(DESIGNID)){
                    int[][] order = getXYorder(seqFolderPath+PREFIX+DESIGNID+".tpmap");
                    tpmapOrder.put(DESIGNID, order);
                }
                int[][] order = (int[][]) tpmapOrder.get(DESIGNID);
                int xDim = order.length;
                int yDim = order[0].length;
                float[][][] data = new float[xDim][yDim][2];     // data[][][0] = IP; data[][][1] = Input
                for (int n =0; n < xDim; n++ ){
                    for (int m =0; m < yDim; m++){
                        data[n][m][0] = data[n][m][1] = -1.0f;
                    }
                }
                readSingleChannel(IPFileName, data, 0);
                readSingleChannel(InputFileName, data, 1);
                fw.write("Creating " + newFileName+"\n");
                writeRawData(newFileName, data, order, DESIGNID);
                System.gc();
            }
        } catch(IOException e){
            
        }
    }
    
    // index = 0 for IP, 1 for Input
    private void readSingleChannel(String filename, float[][][] data, int index){
       try{
            BufferedReader f = new BufferedReader (new FileReader(filename));
            String line;
           
            int X =0, Y=0, PM=0;
            // Get column indices
            while ( (line =f.readLine())!= null) {
                if (line.trim().indexOf("#") == 0) continue;
                else{
                    String[] header = line.split("\t");
                    for (int j = 0; j < header.length; j ++){
                         if (header[j].trim().equals("X")) X = j;
                         else if (header[j].trim().equals("Y")) Y = j;
                         else if (header[j].trim().equals("PM")) PM = j;
                    } 
                    break;
                }
            }
            while ( (line =f.readLine())!= null) {
                String[] l = line.split("\t");
                
                int xLoc = Integer.parseInt(l[X]);
                int yLoc = Integer.parseInt(l[Y]);
                data[xLoc][yLoc][index] = Float.parseFloat(l[PM]);
            }
            
            f.close();
        } catch(IOException e){
            System.out.println("Cannot open " +filename);
        }
        return;
    }
    
    /** Return the line position of (X,Y) entry in .tpmap 
     * if (X,Y) doesn't exist in .tpmap, it's position will be 0 and the corresponding
     * probe will not be stored in the pair data files. 
     */
    private int[][] getXYorder(String tpmapFile){
        int[][] position = null;
        try{
            BufferedReader f = new BufferedReader (new FileReader(tpmapFile));
            String line;
            int xDim = 0, yDim = 0;    
            while ( (line =f.readLine())!= null) {
                if (line.trim().indexOf("#") == 0){
                    if (line.indexOf("XYdimension") >=0){
                        String[] header = line.split("\t");
                        xDim = Integer.parseInt(header[1]);
                        yDim = Integer.parseInt(header[2]);
                    }
                }
                else{
                    break;
                }
            }
            int current = 1;
            //System.out.println("Xdim = " + xDim + ", Ydim = "+yDim);
            position = new int[xDim+1][yDim+1];         // X,Y start from 1; this saves speed
            do{
                String[] l = line.split("\t");
                position[Integer.parseInt(l[4])][Integer.parseInt(l[5])] = current;
                current ++;
            } while ( (line =f.readLine())!= null );
            
            f.close();
            return position;
        } catch(IOException e){
            System.out.println("Cannot open " +tpmapFile);
        }
        return position;
    }
    /** Sort raw data according to chromosome location and output to a file **/
    private void writeRawData(String outFile, float[][][] data, int[][] order, String DESIGNID){
        try{
            ArrayList<float[]> A = new ArrayList<float[]>(10000);
            int xDim = data.length;
            int yDim = data[0].length;
            for (int x =0; x < xDim; x++){
                for(int y = 0; y < yDim; y++){
                    if (data[x][y][0] >= 0.0f && order[x][y] > 0 ){
                        float[] entry = new float[]{ (float) order[x][y], (float) x, (float) y, data[x][y][0], data[x][y][1]};
                        A.add(entry);
                    }
                }
            }
            A.trimToSize();
            float[][] sorted = A.toArray(new float[A.size()][5]);
            UtilityFunctions.sortFloat(sorted);
            FileWriter fo = new FileWriter(new File(outFile));
            fo.write("#DESIGN_ID\t" + DESIGNID+ "\n");
            fo.write("X\tY\tIP\tInput"+ "\n");
            int nLines = sorted.length;
            for (int n = 0; n< nLines; n++){
                float[] line = sorted[n];
                fo.write((int) line[1] + "\t" + (int) line[2] + "\t" + line[3] +"\t" + line[4] + "\n");
            }
            fo.close();
        } catch(IOException e){
            
        }
    }
    private void print(String s){
        System.out.println(s);
    }
    private void print(String[] s){
        for (int i =0; i < s.length; i++){
            System.out.println(s[i]);
        }
    }
    public static void main (String[] argv){
        try{
            File  seq = new File("C:\\cygwin\\home\\jssong\\Research\\FisherLab\\DesignFiles");
            File data = new File("C:\\cygwin\\home\\jssong\\Research\\FisherLab\\PairData");
            FileWriter fo = new FileWriter(new File("C:\\cygwin\\home\\jssong\\Research\\FisherLab\\MA2C_test.log"));
            String[] design = {"1702", "1703"};
            String[][] IP = new String[2][];
            IP[0] = new String[]{"43412","635", "532", "1703"};
            IP[1] = new String[]{"43820", "635", "532", "1702"};
            FileChecker fc = new FileChecker(seq, data, design, IP, fo);
            fc.checkSeq();
            fc.checkRawData();
            fo.close();
        } catch(IOException e){
            
        }
    }
}
