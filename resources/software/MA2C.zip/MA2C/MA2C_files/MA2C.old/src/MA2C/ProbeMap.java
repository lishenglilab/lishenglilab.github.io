/*
 * ProbeMap.java
 *
 * Created on 2006��8��3��, ����12:52
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 *
 * @author zhuxp
 * ProbeMap is a class which contains all the information in tpmap or bpmap.
 * It can transfer x,y coordination in array to chromosome position.
 * It doesn't have the information of experiment file.
 * It only reflects the array design.
 * the experiment file stored in class Ratio
 * MapRatio Class combine Ratio and ProbeMap together.
 */
public class ProbeMap implements Serializable{
    //final int probeNum=600000;
    /*************************************************************/
    /*     The length of the array below is the probe number     */
    /*************************************************************/
    int X[];   //the x position of probe
    int  Y[];  // the y postion of probe
    int Chr[]; // the probe's chromosome using number id
    long Start[];  // the probes' start sites in chrom
    int Len[];     // the probes' length
    long ProbeMiddle[]; //    Start+1/2*(Len)
    /***************        The End of long array     ************/
    
    
    
    int xMax;
    int yMax;
    int ChrNum;   // Chrom number
    int probeNum;  // probe number less than probeNum
    
    int ChrIndex[];// the index of chrom, for example chr1 starts at No.1 probe, while chr2 starts at No.20000 
                   // then ChrIndex[0]=0,ChrIndex[1]=19999, 
                   // according to ChrIndex ,the probes belong to one chrom can be extracted.
   
    
    String ChrID[];// transfer chromosome_number_id into chromosome_id
                    // for example ChrID[0]="chr1" ChrIndex[0]=0
                    // the length of ChrID and ChrIndex is ChrNum
                   
    String filename="";
    /** Creates a new instance of ProbeMap */
    public ProbeMap()
    {
         ChrIndex= new int[20000];
     ChrID= new String[20000]; 
    }
    public ProbeMap(String filename) {
     
     
     /*
     int[] X=null;
     int[] Y=null;
     int[] Chr=null;
     long[] Start=null;
     int[] Len=null;
     long[] ProbeMiddle=null;
     */
     ChrIndex= new int[20000];
     ChrID= new String[20000]; //at most 200 chromosomes
     this.filename=filename;
      readSortMap();
     }
    void readSortMap()
    /*****************************
     * read the tpmap file generated from MA2C
     *
     */
    {
        String line = null;
        ArrayList<Integer> XList= new ArrayList<Integer>();   //the x position of probe
        ArrayList<Integer>  YList = new ArrayList<Integer>();  // the y postion of probe
        ArrayList<Integer>  ChrList = new ArrayList<Integer>(); // the probe's chromosome using number id
        ArrayList<Long> StartList = new ArrayList<Long>();  // the probes' start sites in chrom
        ArrayList<Integer>  LenList = new ArrayList<Integer>();     // the probes' length
        try {
            BufferedReader f = new BufferedReader (new FileReader(filename));
            
            while ( (line =f.readLine())!= null) {
                    if (line.trim().indexOf("#") == 0) {
                         if (line.indexOf("XYdimension") >=0) {
                            String[] l = line.split("\t");
                           
                            //System.err.println("hello"+line);
                            xMax=Integer.valueOf(l[1]);
                            yMax=Integer.valueOf(l[2]);
 //                           System.err.println("inmap:"+xMax+","+yMax);
                            
                             
                        }
                       }      
                    
                    else{
                        break;
                        }
                    }
                 
            //System.out.println(DESIGN_ID+" "+line);
           
            String [] columns = null;
            //now the first dataline is in line
            int i=0;
            int chr_number=-1;//revised in 11-2006
            
            String chr_now="";
           do
            {
                        
                columns = line.split("\t");
                
                String ch=columns[2];
                
                if (!chr_now.equals(ch)) 
                  {
                   chr_now=ch;
                   chr_number++;
       
                   ChrID[chr_number]=chr_now;
                   ChrIndex[chr_number]=i;
                 }
                i++;
                ChrList.add(chr_number);
                XList.add(Integer.parseInt(columns[4]));
                YList.add(Integer.parseInt(columns[5]));
                StartList.add(Long.parseLong(columns[3]));
                LenList.add(columns[0].length());
                }    
            while((line=f.readLine())!= null);
            
           // ProbeMiddle[i]=Start[i]+Len[i]/2;
           
               
            
             
           ChrList.trimToSize();
           XList.trimToSize();
           YList.trimToSize();
           StartList.trimToSize();
           LenList.trimToSize();
            probeNum=ChrList.size();
            ChrNum=chr_number+1;
            ChrIndex[chr_number+1]=probeNum;
            f.close();
           
            } 
       catch (IOException io)
            {
            System.err.print("Cannot open " + filename );
            }
                       
        
        
         try{                       
             X=new int[probeNum];
             Y=new int[probeNum];
             Chr=new int[probeNum];
             Start=new long[probeNum];
             Len=new int[probeNum];
             ProbeMiddle= new long[probeNum];
           }                
         catch (Exception e)
                               {
                                   System.err.println("out of memory"+e);
                               }
        for (int i=0;i<probeNum;i++)
        {
            X[i]=XList.get(i);
            Y[i]=YList.get(i);
            Chr[i]=ChrList.get(i);
            Start[i]=StartList.get(i);
            Len[i]=LenList.get(i);
            ProbeMiddle[i]=Start[i]+Len[i]/2;
        }
        
    }
    private void writeObject(ObjectOutputStream out) throws IOException {
    //Chr Informations
    out.writeObject(filename);
    out.writeInt(xMax);
    out.writeInt(yMax);
    
    out.writeObject(Chr);
    out.writeObject(Start);
    out.writeObject(Len);
    out.writeObject(X);
    out.writeObject(Y);
    
    out.writeObject(ChrID);
    out.writeObject(ChrIndex);
    
                  // Then write it out normally.
  }
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        
        filename=(String)in.readObject();
        xMax = in.readInt();
        yMax = in.readInt();
        
        Chr = (int[]) in.readObject();
        Start = (long[]) in.readObject();
        Len =(int[]) in.readObject();
        X = (int[]) in.readObject();
        Y = (int[]) in.readObject();
        ChrID = (String[]) in.readObject();
        ChrIndex = (int[]) in.readObject();
        probeNum=X.length;
        ProbeMiddle = new long[probeNum];
        ChrNum = ChrID.length;
        for(int i=0;i<probeNum;i++)
        {
            ProbeMiddle[i]=Start[i]+Len[i]/2;
            
        }
    }
    
    public int[]  Locus2ListPos(String chr, long start, long stop)
    {
        int[] a = new int[2];
        int chr_list_start=0;
        int chr_list_stop=0;
        for(int i=0;i<ChrID.length;i++)
        {
            if(chr.equalsIgnoreCase(ChrID[i]))
            {
                chr_list_start=ChrIndex[i];
                chr_list_stop=ChrIndex[i+1]-1;
            }
        }
        
        a[0]=MyStat.PosInSortArray(ProbeMiddle,chr_list_start,chr_list_stop,start)+1;
        a[1]=MyStat.PosInSortArray(ProbeMiddle,chr_list_start,chr_list_stop,stop);
        
        return a;
        
    }
 
    public static void main(String[] args)
    {
     System.err.println("Reading " + args[0]); 
     ProbeMap a = new ProbeMap(args[0]);
     System.err.println("Writing");
     String output=args[0]+".bin.gz";
     GzipIO.writeToGzip(output,a); 
    
     System.err.println("done");
     
     }
     
}
    
    
