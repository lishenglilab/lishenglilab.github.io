/*
 * Bed.java
 *
 * Created on 2006��10��11��, ����12:32
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

import java.text.DecimalFormat;

/**
 *
 * @author zhuxp
 */
public class Bed {
    String Chr;
    long Start;
    long Stop;
    int PeakPos;
    int ProbeNumber;
    double Score;
    double Pvalue;
    double FDR;
    double MA2CScore;
    String ID;
    int negative_or_positive;//negative peaks or positive peaks
    int Strand;
    int len;
    int ProbeStart;
    int ProbeStop;
    
    /** Creates a new instance of Bed */
    public Bed() {
    }
    public Bed(String Chr,long Start,long Stop,double Score)
    {
        this.Chr=Chr;
        this.Start=Start;
        this.Stop=Stop;
        this.Score=Score;
    }
    public Bed(String bed)
    {
        String[] a=bed.split("\t");
        this.Chr=a[0];
        this.Start=Long.valueOf(a[1]);
        this.Stop=Long.valueOf(a[2]);
        this.ID=a[3];
        this.Score=Double.valueOf(a[4]);
    }
    
    
    public String toString()
    {
        DecimalFormat myFormatter= new DecimalFormat("###.#####");
        
        String str=Chr+"\t"+Long.toString(Start)+"\t"+Long.toString(Stop)+"\t"+ID+"\t"+myFormatter.format(Score);
        return str;
    }
    public String toXlsString()
    {
        DecimalFormat myFormatter= new DecimalFormat("###.#####");
        String str=Chr+"\t"+Long.toString(Start)+"\t"+Long.toString(Stop)+"\t"+ID+"\t"+myFormatter.format(Score);
        double P=-10*Math.log10(Pvalue);
        str=str+"\t"+myFormatter.format(P)+"\t"+myFormatter.format(MA2CScore)+"\t"+myFormatter.format(FDR)+"\t"+PeakPos+"\t"+len+"\t"+ProbeNumber;
        return str;
    }
}
