/*
 * pValue.java
 *
 * Created on 2006��8��3??, ����4:12
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author zhuxp
 */
public class MyStat {
    
    /** Creates a new instance of pValue */
    public MyStat() {
    }
public static float mean(Float[] a, int item_number)
{
    float m=0;
    for(int i=0;i<item_number;i++)
    {
        m=m+a[i];
    }
    return m/item_number;
    
}

public static double mean(Double[] a, int item_number)
{
   double m=0;
    for(int i=0;i<item_number;i++)
    {
        m=m+a[i];
    }
    return m/item_number;
    
}
public static double pseudomedian(double[] a)
{
    int len = a.length;
    if(len==1){return a[0];}
    int l=len*(len-1)/2;
    double[] m=new double[l];
    int k=0;
    for(int i=0;i<len;i++)
    {
        for(int j=i+1;j<len;j++)
        {
            m[k]=(a[i]+a[j])/2;
            k++;
        }
        
    }
    return median(m,m.length);
}
public static float mean(Float[] a)
{
    return mean(a,a.length);
}
public static double mean(Double[] a)
{
    return mean(a,a.length);
}
public static double mean(double[] a)
{
  double m=0.0d;
  for(int i=0;i<a.length;i++){m=m+a[i];}
  return m/a.length;
}
public static double trimmean(double[] a)
{
    if(a.length<=2){return mean(a);}
    double[] b=a.clone();
    Arrays.sort(b);
    double m=0.0d;
    for(int i=1;i<b.length-1;i++)
    {
        m=m+b[i];
    }
    return m/(b.length-2);
}
public static Float median(Float[] a)
{
    int k=a.length;
    if(k==1){return a[0];}
    Float[] b=a.clone();
    Arrays.sort(b);
    if (k%2==0) {return (b[k/2]+b[k/2-1])/2;}
    
    int j=(k-1)/2;
 
    return b[j];
}

public static Double median(Double[] a)
{
    int k=a.length;
    if(k==1){return a[0];}
    Double[] b=a.clone();
    Arrays.sort(b);
    
    if (k%2==0) {return (b[k/2]+b[k/2-1])/2;}
    int j=(k-1)/2;

    return b[j];
}

public static double median(double[] a, int k)
{
   
    if(k==1){return a[0];}
    double[] b=a.clone();
    Arrays.sort(b);
   
    if (k%2==0) {return (b[k/2]+b[k/2-1])/2;}
    int j=(k-1)/2;

    return b[j];
}

public static float stderr(Float[] a)
{
    float sd = 0;
    float mean=mean(a);
    for(int i=0;i<a.length;i++)
    {
        sd=sd+(float)((a[i]-mean)*(a[i]-mean));
    }
    //System.out.println("sd in function "+sd);
    sd=sd/(a.length-1);
    sd=(float)Math.sqrt((double)sd);
    
    return sd;
}
public static double stderr(Double[] a)
{
    double sd = 0;
    double mean=mean(a);
    for(int i=0;i<a.length;i++)
    {
        sd=sd+((a[i]-mean)*(a[i]-mean));
    }
    //System.out.println("sd in function "+sd);
    sd=sd/(a.length-1);
    sd=Math.sqrt((double)sd);
    
    return sd;
}
public static int PosInSortArray(float[] array,float ivalue)
{
    int a=PosInSortArray(array,array.length,ivalue);
    return a;
}
public static int PosInSortArray(float[] array,int item_number,float iValue)
{
 int iStart=0,iStop=item_number,iMiddle;
 do
 {
     iMiddle=(iStart+iStop)/2;
     if(iValue==array[iMiddle])
     {
         return iMiddle;
     }
     if(iValue>array[iMiddle])
     {
         iStart=iMiddle;
     }
     else
     {
         iStop=iMiddle;
     }
 }
 while((iStop-iStart)>=2);
 return iStart;
}
public static int PosInSortArray(Float[] array,float iValue)
{
 int iStart=0,iStop=array.length,iMiddle;
 do
 {
     iMiddle=(iStart+iStop)/2;
     if(iValue==array[iMiddle])
     {
         return iMiddle;
     }
     if(iValue>array[iMiddle])
     {
         iStart=iMiddle;
     }
     else
     {
         iStop=iMiddle;
     }
 }
 while((iStop-iStart)>=2);
 return iStart;
}
public static int PosInSortArray(Double[] array,double iValue)
{
 int iStart=0,iStop=array.length,iMiddle;
 do
 {
     iMiddle=(iStart+iStop)/2;
     if(iValue==array[iMiddle])
     {
         return iMiddle;
     }
     if(iValue>array[iMiddle])
     {
         iStart=iMiddle;
     }
     else
     {
         iStop=iMiddle;
     }
 }
 while((iStop-iStart)>=2);
 return iStart;
}
public static int PosInSortArray(double[] array,double iValue)
{
 int iStart=0,iStop=array.length,iMiddle;
 do
 {
     iMiddle=(iStart+iStop)/2;
     if(iValue==array[iMiddle])
     {
         return iMiddle;
     }
     if(iValue>array[iMiddle])
     {
         iStart=iMiddle;
     }
     else
     {
         iStop=iMiddle;
     }
 }
 while((iStop-iStart)>=2);
 return iStart;
}
public static int PosInSortArray(long[] array,int iStart,int iStop,long iValue)
{
int iMiddle;
 do
 {
     iMiddle=(iStart+iStop)/2;
     if(iValue==array[iMiddle])
     {
         return iMiddle;
     }
     if(iValue>array[iMiddle])
     {
         iStart=iMiddle;
     }
     else
     {
         iStop=iMiddle;
     }
 }
 while((iStop-iStart)>=2);
 return iStart;
}
public static void SortBed(Bed[] v)
{
    Arrays.sort(v, new BedArrayComparator());
}

public static void main(String[] args)
{ 
    Float a[] = new Float[5];
    a[0]=0.0F;
    a[2]=3.0F;
    a[1]=4.0F;
    a[3]=9.0F;
    a[4]=10.F;
   
    System.out.println(median(a));
}



}



class BedArrayComparator implements Comparator
{
    public int compare(Object obj1, Object obj2 ) {
        int result = 0;
 
    Bed bedA = (Bed) obj1;
    Bed bedB = (Bed) obj2;
 
    /* Sort on first element of each array (last name) */
    return (new Double(bedB.Score)).compareTo(new Double(bedA.Score));
    }
    
    
}

 



    

