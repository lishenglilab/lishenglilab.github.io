/*
 * Bed2Probes.java
 *
 * Created on 2006��10��16��, ����10:01
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 *
 * @author zhuxp
 * @ This is a separated program which can extract the probe's information
 *   according the genome location information in Bed file
 * 
 */
public class Bed2Probes {
    
    /** Creates a new instance of Bed2Probes */
    public Bed2Probes() {
    }
    
    public static void main(String[] args) {
        if (args.length<2)
        {
            //new Main();
            System.err.println("Usage: java Bed2Probes tagfile bedfile");
        }
        
        else
        {
        TagFile tag = new TagFile(args[0]);    
        //String PQM=tag.getTag("Score");
           //System.out.println("$"+PQM+"$");
          // if (PQM.equals("Pvalue")){System.out.println("error!!!!!!!!!!!");};
        String map_fn=tag.getTag("Tpmap");
        String map_dir=tag.getTag("DesignFilesDir");
        map_fn=map_dir+"/"+map_fn;
        
                //"/Users/zhuxp/Desktop/DesignFiles/MA2C_3426.tpmap";
        String ratio_dir=tag.getTag("PairDataDir");
        String ratio_fn=tag.getTag("RatioData");
        String[] ratio_fns=ratio_fn.split(" ");
        for(int i=0;i<ratio_fns.length;i++)
        {
        ratio_fns[i]=ratio_dir+"/"+ratio_fns[i];
        } 
        //"/Users/zhuxp/Desktop/PairData/MA2C_86699_normalized.txt";        
        System.err.println("Reading Files.....");
        //System.out.println("debug");
        RunPeak e;
       
        if(tag.getTag("Binary").equalsIgnoreCase("true"))
        {
            e = new RunPeak(map_fn,ratio_fns,true);
        }
        else
        {
        e=new RunPeak(map_fn,ratio_fns);
        }
        
           
            try {
                
            
        BufferedReader bedIO=new BufferedReader(new FileReader(args[1]));
       //System.err.println("debug");
        String line="";
        while((line=bedIO.readLine())!=null)
              {
            System.out.println(line);
            if (line.trim().indexOf("#") != 0)
            {
           String[] t=line.split("\t");
           String chr=t[0];
           long start=Long.valueOf(t[1]);
           long stop=Long.valueOf(t[2]);
           String detail=e.Locus2ProbesString(chr,start,stop);
           //System.out.print(line);
           System.out.println(detail);
           System.out.println("=======================================");
            }
        
        
                   }
            }
         catch (Exception ex) {
                ex.printStackTrace();
                
            }
        
        
        
        
        
        
        
        
        }
    
      }
     
}
