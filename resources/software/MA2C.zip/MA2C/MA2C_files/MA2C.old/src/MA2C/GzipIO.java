/*
 * GzipIO.java
 *
 * Created on 2006��10��9��, ����4:58
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 *
 * @author zhuxp
 *
 * This class is IO which can store data in gzip file
 *
 */
public class GzipIO {
    
    /** Creates a new instance of GzipIO */
    public GzipIO() {
    }
    public static Object readFromGzip(String fileName)
    {
        Object a = null;
       //System.out.println(fileName+"!!!!!!!");
     try{
        
         FileInputStream fileIn= new FileInputStream(fileName);
         
         GZIPInputStream  zIn= new GZIPInputStream(fileIn);
          
         ObjectInputStream in = new ObjectInputStream(zIn);
        
       a= in.readObject();
         //  System.out.println(fileName+"!!!!!!!");
        }
       catch (Exception e) {
                          System.out.println(a);
                          System.out.println(e);
                          }
     return a;
        
    }
    
    
    public static void writeToGzip(String fileName,Object a)
    {
         
        try {
      FileOutputStream fileOut = new FileOutputStream(fileName);
      GZIPOutputStream gzOut = new GZIPOutputStream (fileOut);
      ObjectOutputStream out = new ObjectOutputStream(gzOut);
      out.writeObject(a);
      out.flush();
      out.close();
    }
    catch (Exception e) {
      System.out.println(e);
    }
    }
    
}
