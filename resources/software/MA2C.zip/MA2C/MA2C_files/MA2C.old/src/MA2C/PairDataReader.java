/*
 * PairDataReader.java
 *
 * Created on July 25, 2006, 2:31 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;
import java.io.BufferedReader;     
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Vector;
import java.io.FileReader;
import java.util.Hashtable;
import java.lang.Math;
import java.util.ArrayList;
import java.util.Arrays;
/**
 *
 * @author jssong
 */
public class PairDataReader {
    int[][] GCtable;
    final int MAXSIZE = 100;   // Maximum number of GC counts + 1
    final int MINBIN  = 1000;  // Minimum number of probes in a GC bin for mean and variance computation
                               // Bins with less than this number will be pooled with nearby bins.
    /* mean and variance for each bin.  
     * IPMean[i] = mean signal for probes with i GC counts, i = 1,...,99
     * std = std of (IP-Input)
     */
    double[] IPMean ;
    double[] InputMean ;
    double[] std ;
    /** Creates a new instance of PairDataReader */
    public PairDataReader(){}
    
    public PairDataReader(int[][] GCtable) {
        this.GCtable = GCtable;
    }
    
    public void normalizeData(String rawPairFile, double C, boolean robust){
        IPMean = new double[MAXSIZE];
        InputMean = new double[MAXSIZE];
        std = new double[MAXSIZE];
        int[] boundaries  = new int[2];                // Min and Max GC counts
        Double[][][] Data = readData(rawPairFile, boundaries);     // Data in GC bins
                                                       // Data[0][k][] = [IP signals from probes with #GC = k]
                                                       // Data[1][k][] = [Input signals on probes with #GC = k]
        if(robust){
            computeRobustMeanVariance(Data[0],Data[1], 0.001, C, boundaries);
        }
        else{
            computeSimpleMeanVariance(Data[0],Data[1] , boundaries);
        }
    }
    
    private void computeSimpleMeanVariance(Double[][] ipData, Double[][] inputData, int[] boundary){
        // First, estimate the mean and variance for bins with size > MINBIN
        for (int GC=1; GC < MAXSIZE; GC++){
            Double[] ip = ipData[GC];
            Double[] input = inputData[GC];
            double ipmean= 0.0;
            double inputmean = 0.0;
            double tmp = 0.0;
            int nElements = ip.length;
            if ( nElements >= MINBIN){
                for (int i = 0; i < nElements; i ++){
                    ipmean += ip[i];
                    inputmean += input[i];
                }

                ipmean /= nElements;
                inputmean /= nElements;

                IPMean[GC] = ipmean;
                InputMean[GC] = inputmean;
                double variance = 0.0;

                for (int i = 0; i < nElements; i++){
                    tmp = (ip[i] - input[i] - ipmean + inputmean);
                    variance += (tmp*tmp);
                }
                variance /= nElements;
                std[GC] = Math.sqrt(variance);
                
                //System.out.println(GC +" IP mean = " + ipmean + ", input mean = " + inputmean + ", std = " + std[GC]);
            }
        }
         // Set the mean and variance of small bins to those of nearby pooled bins
        int lowest = boundary[0]; int highest  = boundary[1];
        int center = (int)((lowest + highest)/2);
        for (int GC = lowest; GC <= center; GC++){
            Double[] ip = ipData[GC];
            Double[] input = inputData[GC];
            double ipmean= 0.0;
            double inputmean = 0.0;
            double tmp, tmp2, tmp3;
            int nElements = ip.length;
            if ( nElements > 0 && nElements < MINBIN){
                for(int k = GC+1; k < MAXSIZE; k ++){
                    if ( ipData[k].length >= MINBIN){
                        IPMean[GC] = IPMean[k];
                        InputMean[GC] = InputMean[k];
                        std[GC] = std[k];
                        //System.out.println(GC +" " +nElements +" IP mean = " + ipmean + ", input mean = " + inputmean + ", std = " + std[GC]);
                        break;
                    }
                }
            }
        }
        for (int GC = highest; GC > center+1; GC--){
            Double[] ip = ipData[GC];
            Double[] input = inputData[GC];
            
            double tmp, tmp2, tmp3;
            int nElements = ip.length;
            if ( nElements > 0 && nElements < MINBIN){
                for(int k = GC-1; k > 0; k --){
                    if ( ipData[k].length >= MINBIN){
                        IPMean[GC] = IPMean[k];
                        InputMean[GC] = InputMean[k];
                        std[GC] = std[k];
                        //System.out.println(GC +" " +nElements +" IP mean = " + IPMean[GC] + ", input mean = " + InputMean[GC] + ", std = " + std[GC]);
                        break;
                    }
                }
            }
        }
    }
    
    private void computeRobustMeanVariance(Double[][] ipData, Double[][] inputData, double convergence, double C, int[] boundary){
         // First, estimate the mean and variance for bins with size > MINBIN
         for (int GC=1; GC < MAXSIZE; GC++){
            Double[] ip = ipData[GC];
            Double[] input = inputData[GC];
            double ipmean= 0.0;
            double inputmean = 0.0;
            double tmp, tmp2, tmp3;
            int nElements = ip.length;
            if ( nElements >= MINBIN){
        
                double error = 1.0;
                double sig11 = 0.0;
                double sig22 = 0.0;
                double sig12 = 0.0;
                double det_inv = 1;
               
                double[] ipmean_centered = new double[nElements];
                double[] inputmean_centered = new double[nElements];
                
                double[] d = new double[nElements];
                double[] w = new double[nElements];
                double sumw = (double) nElements;
                for (int i = 0; i < nElements; i ++){
                    ipmean += ip[i];
                    inputmean += input[i];
                    w[i] = 1.0;
                }
                ipmean /= nElements;
                inputmean /= nElements;
                for (int i = 0; i < nElements; i ++){
                    ipmean_centered[i] = ip[i] - ipmean;
                    inputmean_centered[i] = input[i]-inputmean;
                    sig11 += (ipmean_centered[i]*ipmean_centered[i]);
                    sig22 += (inputmean_centered[i] * inputmean_centered[i] );
                    sig12 += (ipmean_centered[i]*inputmean_centered[i] );
                }
                sig11 /= sumw;
                sig22 /= sumw;
                sig12 /= sumw;
                det_inv = 1.0/(sig11*sig22 - sig12*sig12);
                while (error >convergence){
                    
                    //resid=dat1-m
                    
                    for (int i = 0; i < nElements; i ++){
                        ipmean_centered[i] = ip[i] - ipmean;
                        inputmean_centered[i] = input[i]-inputmean;
                    }
                   
                    
                    for(int j =0; j < nElements; j ++){
                        d[j] = det_inv * ( sig22*ipmean_centered[j] *ipmean_centered[j]- 2 *sig12 * ipmean_centered[j]* inputmean_centered[j]
                                + sig11*inputmean_centered[j]*inputmean_centered[j]);
                    }
                    //d=sum(dot(resid,LA.inverse(sig))*resid,1)

                    double mad= absmedian(d, nElements);
                    tmp2 = C*mad;
                    sumw = 0.0;
                    
                    for(int j =0; j < nElements; j ++){
                        tmp = d[j]/tmp2;
                        if (tmp > 1){
                            w[j] = 0.0;
                        } else{
                            tmp3 = (1-tmp*tmp);
                            w[j] = tmp3*tmp3;
                            sumw += w[j];
                        }
                    }
                    //u=d/(C*mad)
                    //w=numarray.array((1-u**2)**2)
                    //w[abs(u)>1]=0
                    //sumw=sum(w)
                    double old_ipmean = ipmean;
                    double old_inputmean = inputmean;
                    ipmean = 0.0;
                    inputmean = 0.0;
                    
                    for(int j =0; j < nElements; j ++){
                        ipmean += w[j] * ip[j];
                        inputmean += w[j] * input[j];
                    }
                   
                    
                    //m=numarray.array((sum(w*dat1[:,0])/sumw,sum(w*dat1[:,1])/sumw))
                    ipmean /= sumw;
                    inputmean /= sumw;
                    
                    for (int i = 0; i < nElements; i ++){
                        sig11 += (w[i]*ipmean_centered[i]*ipmean_centered[i]);
                        sig22 += (w[i]*inputmean_centered[i] * inputmean_centered[i] );
                        sig12 += (w[i]*ipmean_centered[i]*inputmean_centered[i] );
                    }
                    sig11 /= sumw;
                    sig22 /= sumw;
                    sig12 /= sumw;
                    det_inv = 1.0/(sig11*sig22 - sig12*sig12);
                    
                    error=Math.max(Math.abs((ipmean -old_ipmean)/(old_ipmean+convergence/10.0)), Math.abs((inputmean -old_inputmean)/(old_inputmean+convergence/10.0)) );
                    
                }
                IPMean[GC] = ipmean;
                InputMean[GC] = inputmean;
                std[GC] = Math.sqrt(sig11 + sig22 - 2 * sig12);
                //System.out.println(GC +" " +nElements +" IP mean = " + ipmean + ", input mean = " + inputmean + ", std = " + std[GC]);
            }
        }
        
        // Set the mean and variance of small bins to those of nearby pooled bins
        int lowest = boundary[0]; int highest  = boundary[1];
        int center = (int)((lowest + highest)/2);
        for (int GC = lowest; GC <= center; GC++){
            Double[] ip = ipData[GC];
            Double[] input = inputData[GC];
            double ipmean= 0.0;
            double inputmean = 0.0;
            double tmp, tmp2, tmp3;
            int nElements = ip.length;
            if ( nElements > 0 && nElements < MINBIN){
                for(int k = GC+1; k < MAXSIZE; k ++){
                    if ( ipData[k].length >= MINBIN){
                        IPMean[GC] = IPMean[k];
                        InputMean[GC] = InputMean[k];
                        std[GC] = std[k];
                        //System.out.println(GC +" " +nElements +" IP mean = " + ipmean + ", input mean = " + inputmean + ", std = " + std[GC]);
                        break;
                    }
                }
            }
        }
        for (int GC = highest; GC > center+1; GC--){
            Double[] ip = ipData[GC];
            Double[] input = inputData[GC];
            
            double tmp, tmp2, tmp3;
            int nElements = ip.length;
            if ( nElements > 0 && nElements < MINBIN){
                for(int k = GC-1; k > 0; k --){
                    if ( ipData[k].length >= MINBIN){
                        IPMean[GC] = IPMean[k];
                        InputMean[GC] = InputMean[k];
                        std[GC] = std[k];
                        //System.out.println(GC +" " +nElements +" IP mean = " + IPMean[GC] + ", input mean = " + InputMean[GC] + ", std = " + std[GC]);
                        break;
                    }
                }
            }
        }
    }
         
    private double absmedian(double[] d, int L){
        double[] tmp = new double[L];
        for (int i =0; i < L; i ++ ){
            tmp[i] = Math.abs(d[i]);
        }
        Arrays.sort(tmp);
        return tmp[ (int) ((L-1)/2)];
        
    }
    
    public static double[] readNormalizedData(String filename){
         String line = null;
         ArrayList<Double> array = new ArrayList<Double>(300000);
         try{
            BufferedReader f = new BufferedReader (new FileReader(filename));
            
            while ( (line =f.readLine())!= null) {
                    if (line.trim().indexOf("#") == 0) continue;
                    else{
                        break;
                    }
            }
            while((line=f.readLine())!= null){
                String[] columns = line.split("\t");
                double IPsignal = Double.parseDouble(columns[2]);
                array.add(IPsignal);
            }
            f.close();
            
         } catch(IOException e){
             
         }
         array.trimToSize();
         int L = array.size();
         double[] A = new double[L];
         for (int k = 0; k <L ; k ++){
             A[k] = array.get(k);
         }         
         return A;
    }
    private Double[][][] readData(String filename, int[] boundaries){
        Vector<String[]> lines = new Vector<String[]>();
        String line = null;
        
        ArrayList<Double>[][] data = new ArrayList[2][MAXSIZE];
        Double[][][] data2 = new Double[2][MAXSIZE][];
        
        // initialize ArrayList and allocate memory to save time
        for (int i = 0; i < MAXSIZE; i++){
            data[0][i] = new ArrayList<Double>(10000);             // IP channel
            data[1][i] = new ArrayList<Double>(10000);             // Input channel
        }
        
        try{
            BufferedReader f = new BufferedReader (new FileReader(filename));
            
            while ( (line =f.readLine())!= null) {
                    if (line.trim().indexOf("#") == 0) continue;
                    else{
                        break;
                    }
            }
           
            /** READ DATA **/
            int GCcount;
            /** Check DESIGN_ID **/
            double log2 = 1.0 /Math.log(2);
            while((line=f.readLine())!= null){
                String[] columns = line.split("\t");
                double IPsignal = Math.log(Float.parseFloat(columns[2])) * log2;
                double inputSignal = Math.log(Float.parseFloat(columns[3])) * log2;
                int X = Integer.parseInt(columns[0]);
                int Y = Integer.parseInt(columns[1]);

                GCcount =  GCtable[X][Y];
                data[0][GCcount].add(IPsignal);
                data[1][GCcount].add(inputSignal);
            }
            
            /**  Convert ArrayList to Double[][][] and pool data for GC bins with low counts **/
            ArrayList<Integer> nonemptybins = new ArrayList<Integer>(20);
            for(int k = 0 ; k < MAXSIZE; k ++){
                data[0][k].trimToSize();
                data[1][k].trimToSize();
                int binSize = data[0][k].size();
                if (binSize > 0){
                    nonemptybins.add(k);
                    //System.out.println(k +" " + binSize);
                }
            }
            nonemptybins.trimToSize();
            int lowest = nonemptybins.get(0);
            int highest = nonemptybins.get(nonemptybins.size()-1);
            int center = (int) ((lowest + highest)/2);
            boundaries[0] = lowest; boundaries[1] = highest;
            //  pool small bins with low GC counts to the right
            for(int k = lowest; k <= center; k ++){
                int binSize = data[0][k].size();
                if ( binSize > 0 && binSize < MINBIN){
                    for (int n = 0; n < binSize; n ++){
                        data[0][k+1].add( (Double) data[0][k].get(n));
                        data[1][k+1].add( (Double) data[1][k].get(n));
                    }
                //data[0][k] = new ArrayList<Double>(0);
                //data[1][k] = new ArrayList<Double>(0);    
                }
            }
            
            // pool small bins with high GC counts to the left
            for(int k = highest; k > center+1; k --){
                int binSize = data[0][k].size();
                if ( binSize > 0 && binSize < MINBIN){
                    for (int n = 0; n < binSize; n ++){
                        data[0][k-1].add( (Double) data[0][k].get(n));
                        data[1][k-1].add( (Double) data[1][k].get(n));
                    }
                //data[0][k] = new ArrayList<Double>(0);
                //data[1][k] = new ArrayList<Double>(0);    
                }
            }
            
            // Convert ArrayList to Double[][][]
            for (int i = 0; i < MAXSIZE; i++){
                
                if (data[0][i].size() == 0) {
                    data2[0][i] = new Double[0];
                    data2[1][i] = new Double[0];
                    continue;
                }
                data2[0][i] =  data[0][i].toArray( new Double[data[0][i].size()]);
                data2[1][i] =  data[1][i].toArray( new Double[data[1][i].size()]);
                //System.out.println(i + " " + (data2[0][i].length));
            }
      
            //System.out.println(seqTable.get("CHR5P64098620")); 
            f.close();
        } catch (IOException io){
            System.err.print("Cannot open " + filename );
        }
        
        return data2;
    }
    
    // Return the standard deviation of the data for final normalization
    private double computeSTD(Vector data, double mean){
        double std = 0.0d;
        int L = data.size();
        for (int i = 0; i < L ; i ++){
            double tmp =  ((double[]) data.elementAt(i))[2];
            tmp = (tmp - mean);
            std +=  (tmp*tmp);
        }
        std = Math.sqrt(std/L);
        return std;
    }
    public void outputNormalizedData(String rawDataFile, String outfile){
        try{
            String line = null;
            BufferedReader f = new BufferedReader (new FileReader(rawDataFile));
            FileWriter fo = new FileWriter(new File(outfile));
            while ( (line =f.readLine())!= null) {
                    if (line.trim().indexOf("#") == 0){
                        fo.write(line+"\n");
                    }
                    else{
                        break;
                    }
            }
            fo.write("X\tY\tNormalizedLog2Ratio\n");
            /** READ DATA **/
            int GCcount;
            /** Check DESIGN_ID **/
            double log2 = 1.0 /Math.log(2);
            Vector v = new Vector();
            double mean = 0;
            while((line=f.readLine())!= null){
                String[] columns = line.split("\t");
                double IPsignal = Math.log(Float.parseFloat(columns[2])) * log2;
                double inputSignal = Math.log(Float.parseFloat(columns[3])) * log2;
                int X = Integer.parseInt(columns[0]);
                int Y = Integer.parseInt(columns[1]);
                GCcount =  GCtable[X][Y];
                double normalized = (IPsignal - inputSignal -IPMean[GCcount] + InputMean[GCcount])/std[GCcount];
                double[] tmp = new double[3];
                tmp[0] = (double) X; tmp[1] = (double) Y; tmp[2] = normalized;
                mean += normalized;
                v.add(tmp);
                
                //fo.write(X +"\t" + Y +"\t" + normalized+"\n");
                //fo.flush();
            }
            int L = v.size();
            double std = computeSTD(v, mean/L);
            double stdinverse = 1/std;
            
            for (int i = 0; i < L; i ++){
                double[] tmp = (double[]) v.elementAt(i);
                int X = (int) tmp[0];
                int Y = (int) tmp[1];
                double normalized = tmp[2]*stdinverse;
                fo.write(X +"\t" + Y +"\t" + normalized+"\n");
                fo.flush();
            }
            f.close();
            fo.close();
        } catch(IOException e){
            
        }
    }
    static public void main (String [] argv){
//        GC_Enumerator GC = new GC_Enumerator("C:\\cygwin\\home\\jssong\\Research\\FisherLab\\DesignFiles\\MA2C_1703.tpmap");
//        PairDataReader pdr = new PairDataReader(GC.GCTable);
//        String file = "C:\\cygwin\\home\\jssong\\Research\\FisherLab\\PairData\\MA2C_43412_raw.txt";
//        String norm = "C:\\cygwin\\home\\jssong\\Research\\FisherLab\\PairData\\MA2C_43412_normalized.txt";
//        pdr.normalizeData(file, 2.0, false);
//        pdr.outputNormalizedData(file,norm);
        
    }
    
}
