package MA2C;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
/*
 * BarWriter.java
 *
 * Created on 2006��10��27��, ����11:33
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author zhuxp
 */
public class BarSequenceItem {
  
    
  public static int BYTE8_FLOAT = 0;
  public static int BYTE4_FLOAT = 1;
  public static int BYTE4_SIGNED_INT = 2;
  public static int BYTE2_SIGNED_INT = 3;
  public static int BYTE1_SIGNED_INT = 4;
  public static int BYTE4_UNSIGNED_INT = 5;
  public static int BYTE2_UNSIGNED_INT = 6;
  public static int BYTE1_UNSIGNED_INT = 7;
  public HashMap m_Parameter = new HashMap();
  public int m_NumberParameters=0;
  public int[] m_Positions;
  public float[] m_Values;
  
  protected static int[] bytes_per_val = {
    8,    // BYTE8_FLOAT
    4,    // BYTE4_FLOAT
    4,    // BYTE4_SIGNED_INT
    2,    // BYTE2_SIGNED_INT
    1,    // BYTE1_SIGNED_INT
    4,    // BYTE4_UNSIGNED_INT
    2,    // BYTE2_UNSIGNED_INT
    1     // BYTE1_UNSIGNED_INT
  };
   String m_Name = "";
   String m_Version = "";
   String m_Group = "";
   int  m_NumberDataPoints = 0;
   
    public static String[] valstrings =
  { "BYTE8_FLOAT", "BYTE4_FLOAT",
    "BYTE4_SIGNED_INT", "BYTE2_SIGNED_INT", "BYTE1_SIGNED_INT",
    "BYTE4_UNSIGNED_INT", "BYTE2_UNSIGNED_INT", "BYTE1_UNSIGNED_INT" };

   
    /** Creates a new instance of BarWriter */
    public BarSequenceItem() {
    }
    public BarSequenceItem(String name,String version,String group,int[] pos,float[] val)
    {
      this.m_Name=name;
      this.m_Version=version;
      this.m_Group=group;
      this.SetData(pos,val);
    }
    public void Write(DataOutput dos) throws IOException
    {
      dos.writeInt(m_Name.length());
      dos.writeBytes(m_Name);
      dos.writeInt(m_Group.length());
      dos.writeBytes(m_Group);
      dos.writeInt(m_Version.length());
      dos.writeBytes(m_Version);

      // should write out all properties from seq and/or graphs as tag/vals?  For now just saying no tag/vals
      dos.writeInt(m_NumberParameters);
      Object[] keys=m_Parameter.keySet().toArray();
    
      for(int i=0;i<m_NumberParameters;i++)
      {
          writeTagVal(dos,(String)keys[i],(String)m_Parameter.get(keys[i]));
      }
      dos.writeInt(this.m_NumberDataPoints);
      for (int i=0; i<m_NumberDataPoints; i++) {
	dos.writeInt(m_Positions[i]);
	dos.writeFloat(m_Values[i]);
      }
    }
    
    public static void writeTagVal(DataOutput dos, String tag, String val)
    throws IOException  {
    dos.writeInt(tag.length());
    dos.writeBytes(tag);
    dos.writeInt(val.length());
    dos.writeBytes(val);
  }
    public static void writeString(DataOutput dos, String str) throws IOException
    {
        int l=str.length();
        dos.writeInt(l);
        dos.writeBytes(str);
    }
    public void SetName(String name)
    {
        this.m_Name=name;
    }
    public String GetName()
    {
        return this.m_Name;
    }
    public void SetVersion(String version)
    {
         this.m_Version=version;   
    }
    public String GetVersion()
    {
        return this.m_Group;
    }
    public void SetGroupName(String group)
    {
        this.m_Group=group;
    }
    public String GetGroupName()
    {
        return this.m_Group;
    }
    public void SetNumberDataPoints(int n)
    {
        this.m_NumberDataPoints=n;
    }
    public int GetNumberDataPoints()
    {
        return this.m_NumberDataPoints;
    }
    
    public void AddParameter(String Tag,String Val)
    {
        this.m_Parameter.put(Tag,Val);
    }
    public String GetParameter(String Tag)
    {
        return (String)this.m_Parameter.get(Tag);
    }
    
    public void SetData(int[] positions,float[] values)
    {
        if (positions == null || values == null)
        {
            this.m_NumberDataPoints=0;
            return;
        }
        if(positions.length!=values.length)
        {
            System.err.println("warning: positions and values are not equal length");
        }
        this.m_Positions=positions;
        this.m_Values=values;
        this.m_NumberDataPoints=values.length;
    }
    public void SetData(long[] positions,double[] values)
    {
       int[] p=new int[positions.length];
       float[] v=new float[values.length];
       for(int i=0;i<p.length;i++){p[i]=(int)positions[i];}
       for(int i=0;i<v.length;i++){v[i]=(float)values[i];}
       this.SetData(p,v);
    }
    public void SetValues(float[] values)
    {
        this.m_Values=values;
    }
    
    
}
