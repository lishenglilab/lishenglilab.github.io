/*
 * UtilityFunctions.java
 *
 * Created on May 3, 2006, 3:35 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;
import java.util.*;
/**
 *
 * @author jssong
 */
public class UtilityFunctions {
    
    /** Creates a new instance of UtilityFunctions */
    public UtilityFunctions() {
    }
   public static String getCurrentTime(){
    String stamp;

    java.util.Calendar cal = java.util.Calendar.getInstance();    
    int day = cal.get(java.util.Calendar.DAY_OF_MONTH);
    int month =  cal.get(java.util.Calendar.MONTH)+1;
    int year =  cal.get(java.util.Calendar.YEAR);
    int hour = cal.get(java.util.Calendar.HOUR);
    int minute = cal.get(java.util.Calendar.MINUTE);
    int second = cal.get(java.util.Calendar.SECOND);
    stamp = year+"."+month+"."+day+"_"+hour + "."+minute+"."+second;
    return stamp;
    }
   
    public static void print(String[] s){
        for (int i =0; i < s.length; i++){
            System.out.print(s[i] + " ");
        }
        System.out.println();
    }
   public static void sort(String[][] v){
       Arrays.sort(v, new  StringArrayComparator());
   }
   public static void sort2(String[][] v){
       Arrays.sort(v, new StringArrayComparator2());
   }
   public static void sortFloat(float[][] v){
       Arrays.sort(v, new FloatArrayComparator());
   }
   public static void main(String[] argv){
       String [][] test = new String[2][];
       test[0] = new String[] {"chr12", "124","foo"};
       test[1] = new String[]{"chrX", "24","foo"};
       UtilityFunctions.sort(test);
       UtilityFunctions.print(test[0]);
       UtilityFunctions.print(test[1]);
       return;
   }
}

class StringArrayComparator implements Comparator
{
  public int compare(Object obj1, Object obj2)
  {
    int result = 0;
 
    String[] str1 = (String[]) obj1;
    String[] str2 = (String[]) obj2;
 
    /* Sort on first element of each array (last name) */
    if ((result = str1[0].compareTo(str2[0])) == 0)
    {
      result = (new Integer(str1[1])).compareTo(new Integer(str2[1]));
    }
 
    return result;
  }
}

class StringArrayComparator2 implements Comparator
{
  public int compare(Object obj1, Object obj2)
  {
    int result = 0;
 
    String[] str1 = (String[]) obj1;
    String[] str2 = (String[]) obj2;
 
    /* Sort on first element of each array (last name) */
    return (new Integer(str1[0])).compareTo(new Integer(str2[0]));
  }
}
 class FloatArrayComparator implements Comparator
{
  public int compare(Object obj1, Object obj2)
  {
    int result = 0;
 
    float[] str1 = (float[]) obj1;
    float[] str2 = (float[]) obj2;
 
    /* Sort on first element of each array (last name) */
    return Float.compare( str1[0], str2[0]);
  }
}
