/*
 * MedianPolish.java
 *
 * Created on 2007�~1��5��, �W�� 11:25
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package MA2C;

/**
 *
 * @author hesm
 */
public class MedianPolish {
    
    /** Creates a new instance of MedianPolish */
    public MedianPolish() {
    }
    
}
